<?
function xtable($arg){
	if(is_array($arg)){
		foreach ($arg as $value) {
			$out[]['value'] = $value;
		}
	}
	else{
		$out[] = $arg;
	}
	return $out;
}