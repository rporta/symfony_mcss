<?php 
function xbug($arg = null, $arg2 = false) {
	$arg3 = str_repeat("-", 50);
	echo "<pre>";
	echo "<".$arg3."\tdbug inside\t".$arg3.">\t\n";
	if (is_array($arg) || is_object($arg)){
		if ($arg2 == true){ 
			print_r(var_dump($arg));
		}
		else {
			print_r($arg);
		}
	}
	else{
		if ($arg2 == true){
			var_dump($arg);
		}
		else{
			echo $arg."\n";
		}
	}
	echo "<".$arg3."\tdbug out\t".$arg3.">\t\n";		
	echo "</pre>";
}