<?php 

/**
* 
*/
class div extends createClass
{
	public $_obj;
	public $_html;
	public $_searchData;

	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set align
			if (empty($this->_searchData['align']) && $this->_searchData['align'] !== 0 ){ 
				$this->_align = false;
			}
			else {
				$this->_align = $this->_searchData['align'];
			}			
			## set obj
			if (!empty($this->_searchData['obj'])){ 
				$this->_obj = $this->_searchData['obj'];
			}
			elseif(!empty($this->_obj)){
				$this->_obj = $this->_obj;
			}
			else {
				$this->_obj = false;
			}
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else{
				$this->_name = $this->_searchData['name'];
			}
			## set style
			if (empty($this->_searchData['style'])){ 
				$this->_style = false;
			}
			else {
				$this->_style = $this->_searchData['style'];
			}
		}
		## set html
		$this->setHtml();
	}
	public function setHtml(){
		$name = $style = "";
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}	
		if($this->_style !== false){ $style = " style='{$this->_style}' ";}

		if(empty($this->_align) && $this->_align !== 0){
			$align = "";
		}
		else{
			$align = $this->align($this->_align);
		}


		$outHtml = "<div {$style} class='{$align}' {$name} >{obj}</div>";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = $value->_html;
			}
			$replace[] = implode(" ", $obj);
		}
		elseif($this->_obj == false){
			$search[] = "{obj}";
			$replace[] = "";
		}
		$this->_html = str_replace($search, $replace, $outHtml);
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
				$this->_js[] = $value->_js;
			}
		}
		else{
			$this->_obj[] = $arg;
			$this->_js[] = $arg->_js;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}