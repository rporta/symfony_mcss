<?php

class breadcrumbs extends createClass
{
	public $_textColor;
	public $_backgroundColor;
	public $_data;
	public $_html;
	public function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set data 	=		'href,text'
			if (!empty($this->_searchData['data'])){ 
				$this->_data = $this->_searchData['data'];
			}
			elseif(!empty($this->_data)){
				$this->_data = $this->_data;
			}
		}
		#set html
		$this->setHtml();
	}
	public function setHtml(){

		$textColor = '';
		$backgroundColor = '';

		
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor); }	
		if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor); }
		
		foreach ($this->_data as $value) {
			$data = explode(",", $value);
			$obj[] = "<a href='{$data[0]}' class='breadcrumb {$textColor}'>{$data[1]}</a>";
		}
		$tmp =
		"<nav class='{$backgroundColor}'>
			<div>
				<div class='col'>
					{obj}
				</div>
			</div>
		</nav>";
		$this->_html = str_replace('{obj}', implode('', $obj), $tmp);
	}
}