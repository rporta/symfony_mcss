<?php 

/**
* 
*/
class section  extends createClass
{
	public $_name;
	public $_textColor;
	public $_backgroundColor;
	public $_obj;
	public $_z;
	public $_searchData;
	public $_js;
	public $_html;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'obj':
						if(is_array($value)){
							foreach ($value as $key3 => $value3) {
								if($value3 || 1){ //tipos de objetos que deseo que tenga container
									$this->_obj[] = $value3;
								}
							}
						}
						else{
							$this->_obj[] = $value;
						}
						break;
				}
			}
		}
		## set z
		if (empty($this->_searchData['z'])){ 
			$this->_z = false;
		}
		else {
			$this->_z = $this->_searchData['z'];
		}

		# set js
		if (!empty($this->_searchData['obj']) ){ 
			$this->_obj = $this->_searchData['obj'];
			$js = "";
			foreach ($this->_obj as $obj){
				$js .= " {$obj->_js} ";
			}
			$this->_js = $js;
		}
		elseif (!empty($this->_obj)){
			$this->_obj = $this->_obj;
			$js = "";
			foreach ($this->_obj as $obj){
				$js .= " {$obj->_js} ";
			}
			unset($obj);
			$this->_js = $js;
		}
		else {
			$this->_js = false;
		}


		if($this->_z !== false){
			$style = "style=' position: absolute; top:0; z-index: {$this->_z}; width: 100%; height: 100%'";
		}
		if($this->_name !== false){
			$name = " name='{$this->_name}' ";
		}		
		$outHtml = "<div class='section {class}' $style $name>{obj}</div>";
		$search[] = "{class}";
		$replace[] = "{$this->_backgroundColor} {$this->_textColor} ";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = $value->_html;
			}
			$replace[] = implode(" ", $obj);
		}
		
		

		$this->_html = str_replace($search, $replace, $outHtml);
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
			}
		}
		else{
			$this->_obj[] = $arg;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}