<?php

class pagTemplate
{
	private $_html;
	public function __construct($arg){
		# preloadFull *****************************

		$section['name'] = "section_preload";
		$section['backgroundColor'] = "orange,6";
		$preloader['type'] = 0;
		$preloader['size'] = 2;
		$preloader['backgroundColor'][] = "blue,5";
		$preloader['backgroundColor'][] = "red,2";
		$preloader['backgroundColor'][] = "green,2";

		$preloadFull = new preloadFull($section,$preloader); 

		# preloadFull *****************************

		## pag
		$pag['backgroundColor'] = "blue,6";
		$pag['version'] = true;
		$pag = new pag($pag);

			## header
			$header = new header();
				
				## conteiner_1
				$conteiner_1['center'] = true;
				$conteiner_1 = new conteiner($conteiner_1);

					## titulo
					$titulo['align'] = 1;
					$titulo['textColor'] = "b_w_t,1";
					$titulo['text'] = "Proyecto : {$arg} ";
					$titulo = new h($titulo);

				$conteiner_1->addObj($titulo);

			$header->addObj($conteiner_1);

			## main
			$main = new main();

			## footer
			$footer = new footer();

		$pag->addObj($preloadFull);
		$pag->addObj($header);
		$pag->addObj($main);
		$pag->addObj($footer);
		
		$this->_html = str_replace("cms/", "", $pag->render('export'));

	}
	public function getInfo(){
		return $this->_html;
	}
}