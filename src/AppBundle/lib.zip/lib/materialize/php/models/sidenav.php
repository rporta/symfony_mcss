<?php

class sidenav extends createClass
{
	public $_html;
	public $_js;
	
	public function __construct($listObj, $botton, $slidenav = null){

		if(!empty($slidenav['edge'])){
			$edge = ($slidenav['edge'] == 0 ) ? "left" : "right" ;
		}
		else{
			$edge = "left";
		}

		## set id
		$this->autoId(3);

		$botton['dataTarget'] = $this->_id;

		$this->_html = "<ul id='{$this->_id}' class='sidenav'>{obj}</ul>";

		foreach ($listObj as $value) {
			$obj = "<li>";
			$obj .= $value->_html;
			$obj .= "</li>";

			$objList[] = $obj;

			$obj = "";
		}


		$this->_html = str_replace("{obj}",implode("", $objList), $this->_html);

		$a = new button($botton);

		$a = $a->_html;

		foreach ($listObj as $value) {
			$this->_js .= " $value->_js ";

		}
		# set js  // inicializa todos los slidenav
		$this->_js = " $('.sidenav').sidenav({edge: '{$edge}'}); $('.sidenav-overlay').css('z-index', '1');";

		$this->_html .= $a;
	}

	public function autoId($arg){
		$hash = $this->randHash($arg);
		if(in_array($hash, input::$idList)){
			$this->autoId($arg);
		}
		else{
			$this->_id = input::$idList[] = $hash;
		}
	}
}