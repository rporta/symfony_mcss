<?php 

/**
* 
*/
class cards extends createClass
{
	
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set type
			if (empty($this->_searchData['type'])){ 
				$this->setType();
			}
			else {
				$this->setType($this->_searchData['type']);
			}
		}
		## set html
		$this->setHtml();
	}
	public function setType($arg = null){
		switch (1) {
			case $arg == 0:
			$this->_type = 'Basic Card';
			break;
			case $arg == 1:
			$this->_type = 'Image Card';
			break;
			case $arg == 2:
			$this->_type = 'FABs in Cards';
			break;
			case $arg == 3:
			$this->_type = 'Horizontal Card';
			break;
			case $arg == 4:
			$this->_type = 'Card Reveal';
			break;
			case $arg == 5:
			$this->_type = 'Tabs in Cards';
			break;
			case $arg == 6:
			$this->_type = 'Card Sizes';
			break;
			case $arg == 7:
			$this->_type = 'Card Panel';
			break;
			default:
			$this->_type = 'Basic Card';
			break;
		}	
	}
}