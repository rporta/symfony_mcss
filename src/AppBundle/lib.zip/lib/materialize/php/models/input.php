<?php


## en input hay que agregar al destructor que cuantifique negativo

class input extends createClass
{
	static public $idList = array();

	public $_id;
	public $_name;
	public $_type;
	public $_backgroundColor;
	public $_textColor;
	public $_checked;
	public $_disabled;
	public $_mode;
	public $_value;
	public $_text;
	public $_opt;
	public $_obj;
	public $_dataComplete;
	public $_range;
	public $_vertical;
	
	public $_html;
	public $_js;
	public $_searchData;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function autoId($arg){
		$hash = $this->randHash($arg);
		if(in_array($hash, input::$idList)){
			$this->autoId($arg);
		}
		else{
			$this->_id = input::$idList[] = $hash;
		}
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			
			## set id
			$this->autoId(3);

			## set maxLength
			if (empty($this->_searchData['maxLength'])){ 
				$this->_maxLength = false;
			}
			else {
				$this->_maxLength = $this->_searchData['maxLength'];
			}
			## set characterCount
			if (empty($this->_searchData['characterCount'])){ 
				$this->_characterCount = false;
			}
			else {
				$this->_characterCount = $this->_searchData['characterCount'];
			}
			## set customError
			if (empty($this->_searchData['customError'])){ 
				$this->_customError = false;
			}
			else {
				$this->_customError = $this->_searchData['customError'];
			}
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set range
			if (empty($this->_searchData['range'])){ 
				$this->_range = false;
			}
			else {
				$this->_range = $this->_searchData['range'];
			}
			## set vertical
			if (empty($this->_searchData['vertical'])){ 
				$this->_vertical = false;
			}
			else {
				$this->_vertical = $this->_searchData['vertical'];
			}
			## set opt
			if (empty($this->_searchData['opt'])){ 
				$this->_opt = false;
			}
			else {
				$this->_opt = $this->_searchData['opt'];
			}
			## set text
			if (empty($this->_searchData['text'])){ 
				$this->_text = false;
			}
			else {
				$this->_text = $this->_searchData['text'];
			}
			## set type
			if (empty($this->_searchData['type'])){ 
				$this->setType();
			}
			else {
				$this->setType($this->_searchData['type']);
			}
			## set checked
			if (empty($this->_searchData['checked'])){ 
				$this->_checked = false;
			}
			else {
				$this->_checked =  $this->_searchData['checked'];
			}
			## set disabled
			if (empty($this->_searchData['disabled'])){ 
				$this->_disabled = false;
			}
			else {
				$this->_disabled =  $this->_searchData['disabled'];
			}
			## set mode
			if (empty($this->_searchData['mode'])){ 
				$this->setMode();
			}
			else {
				$this->setMode($this->_searchData['mode']);
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set obj
			if (!empty($this->_searchData['obj'])){ 
				$this->_obj = $this->_searchData['obj'];
			}
			elseif(!empty($this->_obj)){
				$this->_obj = $this->_obj;
			}
			else {
				$this->_obj = false;
			}
			## set dataComplete
			if (!empty($this->_searchData['dataComplete'])){ 
				$this->_dataComplete = $this->_searchData['dataComplete'];
			}
			elseif(!empty($this->_dataComplete)){
				$this->_dataComplete = $this->_dataComplete;
			}
			else {
				$this->_dataComplete = false;
			}
			## set data
			if (!empty($this->_searchData['loadData'])){ 
				$this->_data = $this->_searchData['loadData'];
			}
			elseif(!empty($this->_data)){
				$this->_data = $this->_data;
			}
			else {
				$this->_data = false;
			}
			## set placeholder
			if (!empty($this->_searchData['placeholder'])){ 
				$this->_data = $this->_searchData['placeholder'];
			}
			elseif(!empty($this->_data)){
				$this->_data = $this->_data;
			}
			else {
				$this->_data = false;
			}
		}

		## set html
		$this->setHtml();
	}

	public function setHtml(){
		if($this->_type == "Autocomplete"){
			$this->_autocomplete();
		}
		if($this->_type == "Checkboxes"){
			$this->_checkbox();
		}
		if($this->_type == "Chips"){
			$this->_chips();
		}
		if($this->_type == "Pickers"){
			$this->_pickers();
		}
		if($this->_type == "Radio Buttons"){
			$this->_radioButtons();
		}
		if($this->_type == "Range"){
			$this->_range();
		}
		if($this->_type == "Select"){
			$this->_select();
		}
		if($this->_type == "Switches"){
			$this->_switch();
		}
		if($this->_type == "Text Inputs"){
			$this->_textInputs();
		}
		if($this->_type == "File"){
			$this->_file();
		}

	}
	public function _file(){
		$id = $this->_id;
		$disabled = "";
		$textColor = "";
		$name = "";
		$text = "";
		$placeholder = "";
		$multiple = "";

		//Placeholder
		if($this->_data !== false){ $placeholder = " placeholder='{$this->_data}' ";}

		if($this->_disabled !== false){ $disabled = " disabled ";}
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}		
		if($this->_text !== false){ $text = $this->_text;}

		if($this->_mode == 'normal'){

		}
		elseif($this->_mode == 'multiple'){
			$multiple = " multiple ";
		}
		$tmp = 
		"<div class='file-field input-field'>
			<div class='btn'>
				<span>{$text}</span>
				<input type='file' {$name} {$multiple} >
			</div>
				<div class='file-path-wrapper'>
				<input class='file-path validate {$textColor}' type='text' {$placeholder}>
			</div>
		</div>";
		$this->_html = $tmp;

	}
	public function _textInputs(){
		$id = $this->_id;
		$disabled = "";
		$backgroundColor = "";
		$textColor = "";
		$name = "";
		$text = "";
		$maxLength = "";
		$customError = "";
		$placeholder = "";
		$value = "";
		$ico = "";
		$customError = "";
		if($this->_disabled !== false){ $disabled = " disabled ";}
		// if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor);}
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}		
		if($this->_text !== false){ $text = $this->_text;}
		if($this->_maxLength !== false){ 
			$maxLength = " data-length='{$this->_maxLength}' maxlength='{$this->_maxLength}' ";
			//characterCount
			if($this->_characterCount !== false){ 
				$this->_js[] = " $('#{$id}').characterCounter(); ";
			}
		}
		if($this->_customError !== false){ $customError = "<span class='helper-text' data-error='{$this->_customError[0]}' data-success='{$this->_customError[1]}'>{$this->_customError[2]}</span>";}
		//Placeholder
		if($this->_data !== false){ $placeholder = " placeholder='{$this->_data}' ";}
		//value
		if($this->_dataComplete !== false){ $value = $this->_dataComplete;}
		//ico
		if(is_object($this->_obj)){
			$ico = $this->_obj->_html;
			$ico = str_replace("class='", "class='prefix ", $ico);
		}
		elseif($this->_obj == true){
			$ico = "<i class='material-icons prefix'>mode_edit</i>";
		}

		//set mode
		if($this->_mode == "text"){
			//value
			if($this->_dataComplete !== false){ $value = " value = '{$this->_dataComplete}' ";}
			$tmp =
			"<div class='input-field'>
				{$ico}
				<input {$name} {$disabled} {$placeholder} id='{$id}' type='text' class='validate {$backgroundColor} {$textColor}' {$maxLength} {$value}>
				<label class='{$backgroundColor} {$textColor}' for='{$id}'>{$text}</label>
				{$customError}
			</div>";
		}
		elseif($this->_mode == "password"){
			//value
			if($this->_dataComplete !== false){ $value = " value = '{$this->_dataComplete}' ";}

			$tmp =
			"<div class='input-field'>
				{$ico}
				<input {$name} {$disabled} {$placeholder} id='{$id}' type='password' class='validate {$backgroundColor} {$textColor}' {$maxLength} {$value}>
				<label class='{$backgroundColor} {$textColor}' for='{$id}'>{$text}</label>
				{$customError}
			</div>";

		}
		elseif($this->_mode == "email"){
			//value
			if($this->_dataComplete !== false){ $value = " value = '{$this->_dataComplete}' ";}

			$tmp =
			"<div class='input-field'>
				{$ico}
				<input {$name} {$disabled} {$placeholder} id='{$id}' type='email' class='validate {$backgroundColor} {$textColor}' {$maxLength} {$value}>
				<label class='{$backgroundColor} {$textColor}' for='{$id}'>{$text}</label>
				{$customError}
			</div>";

		}
		elseif($this->_mode == "Textarea"){
			//value
			if($this->_dataComplete !== false){ 
				$value = $this->_dataComplete;
				$this->_js[] = 
				"$('#{$id}').val(`{$value}`);
				M.updateTextFields();";
			}			
			$tmp =
			"<div class='input-field'>
				{$ico}
				<textarea {$name} {$placeholder} {$disabled} id='{$id}' class='materialize-textarea {$backgroundColor} {$textColor} ' {$maxLength}></textarea>
				<label class='{$backgroundColor} {$textColor}' for='{$id}'>{$text}</label>
				{$customError}
			</div>";
		}
		
		$this->_html = $tmp;

	}


	/**
	$opt[0]['img'] 
	$opt[0]['value'] 
	$opt[0]['text']
	$opt[0]['group']
	*/
	public function _range(){
		$backgroundColor = "";
		$textColor = "";
		$name = "";
		$style = "";
		$range = array(0 => 0, 1 => 100);
		$orientation = "horizontal";
		$data = array(0 => 0, 1 => 100);
		$id = $this->_id;

		// if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor);}
		// if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}		
		if($this->_vertical !== false){ $orientation = "vertical"; $style = " style='height: 150px;' "; unset($data); $data[] = 0;}
		if($this->_range !== false){ $range = $this->_range;}
		// xbug($this->_mode);

		if($this->_mode == "noUiSlider"){

			$tmp = "<div {$style} class='{$textColor} {$backgroundColor}' id='{$id}' {$name}></div>";

			#set js
			if($this->_data !== false){ 
				unset($data); 
				foreach ($this->_data as $value) {
					$data[] = $value;
				}
				$load = implode(", ", $data);
			}
			$this->_js = 
			"var slider = document.getElementById('{$id}');
			noUiSlider.create(slider, {
				start: [{$data[0]}, {$data[1]}],
				connect: true,
				step: 1,
				orientation: '{$orientation}',
				range: {
					'min': {$range[0]},
					'max': {$range[1]}
				},
				format: wNumb({
					decimals: 0
				})
			});";
		}
		elseif($this->_mode == "HTML5 Range"){
			$value = "";
			if($this->_data !== false){ 
				unset($data); 
				$value = "value='{$this->_data[0]}'";
			}
			

			$tmp =
			"<p class='range-field'>
				<input {$value} style='border: none;' class='{$textColor} {$backgroundColor}' type='range' id='test5' min='{$range[0]}' max='{$range[1]}' {$name} />
			</p>";
		}

		$this->_html = $tmp;

	}
	public function _radioButtons(){
		$checked = "";
		$disabled = "";
		$backgroundColor = "";
		$textColor = "";
		$name = "";
		$text = "";
		$class = "";

		if($this->_checked !== false){ $checked = " checked ";}
		if($this->_disabled !== false){ $disabled = " disabled='disabled' ";}
		if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor);}
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}		
		if($this->_text !== false){ $text = $this->_text;}

		if($this->_mode == "normal"){

		}
		elseif($this->_mode == "With Gap"){
			$class = 'with-gap';
		}

		$tmp = 
		"<label>
			<input class='{$class} {$textColor} {$backgroundColor}' {$name} type='radio' {$checked} {$disabled} />
			<span class='{$textColor}'>{$text}</span>
		</label>";

		$this->_html = $tmp;

	}
	public function _select(){
		$checked = "";
		$disabled = "";
		$textColor = "";
		$multiple = "";
		$class = "";
		$name = "";
		$id = $this->_id;
		if($this->_name !== false){ 
			$name = " name='{$this->_name}' ";
		}	

		if($this->_mode == "normal"){
			$option[] = "<option value='' disabled selected>Seleccione una opcion </option>";
			foreach ($this->_opt as $value) {
				$option[] = "<option value='{$value['value']}'>{$value['text']}</option>";
			}
		}

		elseif($this->_mode == "multiple"){
			$multiple = ' multiple ';
			$option[] = "<option value='' disabled selected>Seleccione una opcion </option>";
			foreach ($this->_opt as $value) {
				$option[] = "<option value='{$value['value']}'>{$value['text']}</option>";
			}			
		}

		elseif($this->_mode == "groups"){
			foreach ($this->_opt as $value) {
				$groups[] = $value['group'];
			}
			$groups = array_unique($groups);
			foreach ($groups as $value) {
				$tmpO = 
				"<optgroup label='{$value}'>
				{option}
				</optgroup>";							
				foreach ($this->_opt as $opt) {
					if($value == $opt['group']){
						$optionGroup[] = "<option value='{$opt['value']}'>{$opt['text']}</option>";
					}
				}
				$tmpO = str_replace("{option}", implode("", $optionGroup), $tmpO);
				unset($optionGroup);
				$option[] = $tmpO;
			}
			
		}

		elseif($this->_mode == "img"){
			$class = " icons ";
			$option[] = "<option value='' disabled selected>Seleccione una opcion </option>";
			foreach ($this->_opt as $value) {
				$option[] = "<option value='{$value['value']}' data-icon='{$value['img']}' class='left' >{$value['text']}</option>";
			}			
		}
		elseif($this->_mode == "browser-default"){
			$option[] = "<option value='' disabled selected>Seleccione una opcion </option>";
			foreach ($this->_opt as $value) {
				$option[] = "<option value='{$value['value']}'>{$value['text']}</option>";
			}
		}

		$tmp = 
		"<select {$multiple} class= '{$class}' {$name} id='{$id}'>
		{option}
		</select>";

		$this->_html = str_replace('{option}', implode("", $option), $tmp);
		

		#set js
		$this->_js = " $('#{$id}').formSelect(); ";
	}
	public function _switch(){
		$checked = "";
		$disabled = "";
		$textColor = "";
		$name = "";

		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_disabled !== false){ $disabled = " disabled ";}
		if($this->_checked !== false){ $checked = " checked='checked' ";}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}				
		$this->_html =
		"<div class='switch' >
		<label class='{$textColor}'>
		Off
		<input type='checkbox' {$checked} {$disabled} {$name}>
		<span class='lever'></span>
		On
		</label>
		</div>";		
	}
	public function _pickers(){
		
		$textColor = "";
		$name = "";
		$class = "";

		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}	



		if($this->_mode == "Date Picker"){
			$class = "class='datepicker'";

			#set js
			$this->_js = " $('.datepicker').datepicker(); ";
		}
		elseif($this->_mode == "Time Picker"){
			$class = "class='timepicker'";

			#set js
			$this->_js = " $('.timepicker').timepicker(); ";			
		}		
		$this->_html =
		"<input type='text' {$class} {$name}>";		
	}
	public function _chips(){

		$backgroundColor = "";
		$textColor = "";
		$name = "";
		$id = $this->_id;
		// if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor);}
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}


		if($this->_mode == "normal"){
			$this->_html =
			"<div class='chips'>
				<input class='custom-class {$textColor} ' {$name}>
			</div>";

			#set js
			$this->_js = " $('.chips').chips(); ";
		}
		elseif($this->_mode == "data"){
			$this->_html =
			"<div class='chips' id='{$id}'>
				<input class='custom-class {$textColor} ' {$name}>
			</div>";

			$js = 
			" $('#{$id}').chips({
				data: [
					{dataComplete}
				]
			}); ";
			unset($replace);

			foreach ($this->_data as $value) {
				$data[] = "{ tag : '{$value}' }";
			}

			$this->_js = str_replace("{dataComplete}", implode(", ", $data), $js);
		}			
		elseif($this->_mode == "placeholders"){
			$this->_html =
			"<div class='chips' id='{$id}'>
				<input class='custom-class {$textColor} ' {$name}>
			</div>";

			$js = 
			" $('#{$id}').chips({
				{dataComplete}
			}); ";
			unset($replace);

			$data[] = "placeholder : '{$this->_data[0]}'";
			$data[] = "secondaryPlaceholder : '{$this->_data[1]}'";

			$this->_js = str_replace("{dataComplete}", implode(", ", $data), $js);
		}			
		elseif($this->_mode == "autocomplete"){

			$this->_html =
			"<div class='chips' id='{$id}'>
				<input class='custom-class {$textColor}' {$name}>
			</div>";

			#set js

			$js= 
			" $('#{$id}').chips({
    			autocompleteOptions: {
					data: {
						{dataComplete}
					},
					limit: Infinity,
      				minLength: 1
				}
			}); ";
			unset($replace);

			foreach ($this->_dataComplete as $key => $value) {
				$src = empty($value) ? "null" : "'{$value}'";
				$data[] = "\"{$key}\": {$src}";
			}

			$this->_js = str_replace("{dataComplete}", implode(", ", $data), $js);
		}			
	}
	public function _autocomplete(){
		$temp =
		"<div class='input-field'>
			{ico}
			<input type='text' id='{name}' name='{name}' class='autocomplete'>
			<label for='autocomplete-input'>{text}</label>
		</div>";
		$search[] = "{ico}";
		$search[] = "{name}";
		$search[] = "{text}";

		if($this->obj == false){
			$replace[] = "<i class='material-icons prefix'>textsms</i>";
		}else{
			$replace[] = str_replace("class='", "class='prefix ", $this->obj[0]->_html);
		}
		$replace[] = $this->_name;
		$replace[] = $this->_text;


		$this->_html = str_replace($search, $replace, $temp);
		
		$js = 
		" $('#{$this->_name}').autocomplete({
			data: {
				{dataComplete}
			},
		}); ";
		unset($replace);

		foreach ($this->_dataComplete as $key => $value) {
			$src = empty($value) ? "null" : "'{$value}'";
			$data[] = "\"{$key}\": {$src}";
		}

		$this->_js = str_replace("{dataComplete}", implode(", ", $data), $js);

	}
	public function _checkbox(){
		$checked = "";
		$disabled = "";
		$indeterminate = "";
		$class = "";
		$text = "";
		$name = "";

		if($this->_mode == "normal"){
			if($this->_checked !== false){ $checked = " checked='checked' ";}
			if($this->_disabled !== false){ $disabled = " disabled='disabled' ";}
		}
		elseif($this->_mode == "filled"){
			if($this->_checked !== false){ $checked = " checked='checked' ";}
			if($this->_disabled !== false){ $disabled = " disabled='disabled' ";}
			$class = " filled-in ";
		}
		elseif($this->_mode == "indeterminate"){
			$indeterminate = "id='indeterminate-checkbox'";
		}

		if($this->_text !== false){ $text = $this->_text;}
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}

		$temp = 
		"<label>
		<input type='checkbox' class='{class}' {$disabled} {name} {indeterminate} {checked}/>
		<span>{text}</span>
		</label>";
		
		$search[] = '{class}';
		$search[] = '{name}';
		$search[] = '{indeterminate}';
		$search[] = '{checked}';
		$search[] = '{text}';

		$replace[] = $class;
		$replace[] = $name;
		$replace[] = $indeterminate;
		$replace[] = $checked;
		$replace[] = $text;

		$this->_html = str_replace($search, $replace, $temp);
	}
	public function setType($arg = null){
		switch (1) {
			case $arg == 0:
			$this->_type = 'Autocomplete';
			break;
			case $arg == 1:
			$this->_type = 'Checkboxes';
			break;
			case $arg == 2:
			$this->_type = 'Chips';
			break;
			case $arg == 3:
			$this->_type = 'Pickers';
			break;
			case $arg == 4:
			$this->_type = 'Radio Buttons';
			break;
			case $arg == 5:
			$this->_type = 'Range';
			break;
			case $arg == 6:
			$this->_type = 'Select';
			break;
			case $arg == 7:
			$this->_type = 'Switches';
			break;
			case $arg == 8:
			$this->_type = 'Text Inputs';
			break;
			case $arg == 9:
			$this->_type = 'File';
			break;
			default:
			$this->_type = 'Checkboxes';
			break;
		}	
	}
	public function setMode($arg = null){
		if ($this->_type == 'Checkboxes'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'normal';
				break;
				case $arg == 1:
				$this->_mode = 'filled';
				break;
				case $arg == 2:
				$this->_mode = 'indeterminate';
				break;
				default:
				$this->_mode = 'normal';
				break;
			}	
		}
		elseif ($this->_type == 'Select'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'normal';
				break;
				case $arg == 1:
				$this->_mode = 'multiple';
				break;
				case $arg == 2:
				$this->_mode = 'groups';
				break;
				case $arg == 3:
				$this->_mode = 'img';
				break;
				case $arg == 4:
				$this->_mode = 'browser-default';
				break;
				default:
				$this->_mode = 'normal';
				break;					
			}	
		}
		elseif ($this->_type == 'Chips'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'normal';
				break;
				case $arg == 1:
				$this->_mode = 'data';
				break;
				case $arg == 2:
				$this->_mode = 'placeholders';
				break;
				case $arg == 3:
				$this->_mode = 'autocomplete';
				break;
				default:
				$this->_mode = 'normal';
				break;					
			}	
		}
		elseif ($this->_type == 'Pickers'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'Date Picker';
				break;
				case $arg == 1:
				$this->_mode = 'Time Picker';
				break;
				default:
				$this->_mode = 'Date Picker';
				break;					
			}	
		}		
		elseif ($this->_type == 'Radio Buttons'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'normal';
				break;
				case $arg == 1:
				$this->_mode = 'With Gap';
				break;
				default:
				$this->_mode = 'normal';
				break;					
			}	
		}		
		elseif ($this->_type == 'Range'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'noUiSlider';
				break;
				case $arg == 1:
				$this->_mode = 'HTML5 Range';
				break;
				default:
				$this->_mode = 'HTML5 Range';
				break;					
			}	
		}		
		elseif ($this->_type == 'Text Inputs'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'text';
				break;
				case $arg == 1:
				$this->_mode = 'password';
				break;
				case $arg == 2:
				$this->_mode = 'email';
				break;
				case $arg == 3:
				$this->_mode = 'Textarea';
				break;
				default:
				$this->_mode = 'text';
				break;					
			}	
		}		
		elseif ($this->_type == 'File'){
			switch (1) {
				case $arg == 0:
				$this->_mode = 'normal';
				break;
				case $arg == 1:
				$this->_mode = 'multiple';
				break;
				default:
				$this->_mode = 'normal';
				break;					
			}	
		}		
	}
}


