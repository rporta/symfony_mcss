<?php 

/**
* 
*/
class main extends createClass
{
	public $_name;
	public $_textColor;
	public $_backgroundColor;
	public $_obj;
	public $_searchData;
	public $_html;
	public $_js;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'obj':
						if(is_array($value)){
							foreach ($value as $key3 => $value3) {
								if(
									$value3 instanceof conteiner ||
									$value3 instanceof col 
								){ //tipos de objetos que deseo que tenga container
									$this->_obj[] = $value3;
									$this->_js[] = $value3->_js;
								}
							}
						}
						else{
							$this->_obj[] = $value;
							$this->_js[] = $value->_js;
						}
						break;
				}
			}
		}
		$outHtml = "<main class='{class}'>{obj}</main>";
		$search[] = "{class}";
		$replace[] = "{$this->_backgroundColor} {$this->_textColor} ";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = $value->_html;
			}
			$replace[] = implode(" ", $obj);
		}
		else if($this->_obj == ""){
			$search[] = "{obj}";
			$replace[] = "";
		}
		
		

		$this->_html = str_replace($search, $replace, $outHtml);
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
				$this->_js[] = $value->_js;
			}
		}
		else{
			$this->_obj[] = $arg;
			$this->_js[] = $arg->_js;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}