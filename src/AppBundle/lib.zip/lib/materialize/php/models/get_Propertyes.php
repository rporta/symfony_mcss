<?php 

class getProperties 
{
	public $truncate;
	public $pulse;	
	public $hoverable;
	public $flow_text;
	public function __construct(){
		$this->truncate = "truncate";
		$this->pulse = "pulse";
		$this->hoverable = "hoverable";
		$this->flow_text = "flow-text";
	}
	public function randHash($len=32){
		return substr(md5(openssl_random_pseudo_bytes(20)),-$len);
	}
	public function createId($arg){
		$seach = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞ
		ßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿŔŕ- ';
		$replace = 'aaaaaaaceeeeiiiidnoooooouuuuy
		bsaaaaaaaceeeeiiiidnoooooouuuyybyRr__';
		$string = utf8_decode($arg);
		$string = strtr($string, utf8_decode($seach), $replace);
		$string = strtolower($string);
		return utf8_encode($string);
	}
	public function listColor(){
		for ($i=0; $i <= 13 ; $i++) { 
			$listColor[] = "red,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "pink,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "purple,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "deep_purple,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "indigo,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "blue,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "light_blue,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "cyan,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "teal,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "green,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "light_green,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "lime,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "yellow,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "amber,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "orange,{$i}";
		}
		for ($i=0; $i <= 13 ; $i++) {
			$listColor[] = "deep_orange,{$i}";
		}


		for ($i=0; $i <= 9 ; $i++) {
			$listColor[] = "brown,{$i}";
		}
		for ($i=0; $i <= 9 ; $i++) {
			$listColor[] = "grey,{$i}";
		}
		for ($i=0; $i <= 9 ; $i++) {
			$listColor[] = "blue_grey,{$i}";
		}

		for ($i=0; $i <= 2 ; $i++) {
			$listColor[] = "b_w_t,{$i}";
		}


		return $listColor;
	}
	public function arrayColors(){
		$red = "#ffebee red lighten-5,#ffcdd2 red lighten-4,#ef9a9a red lighten-3,#e57373 red lighten-2,#ef5350 red lighten-1,#f44336 red,#e53935 red darken-1,#d32f2f red darken-2,#c62828 red darken-3,#b71c1c red darken-4,#ff8a80 red accent-1,#ff5252 red accent-2,#ff1744 red accent-3,#d50000 red accent-4";
		$pink = "#fce4ec pink lighten-5,#f8bbd0 pink lighten-4,#f48fb1 pink lighten-3,#f06292 pink lighten-2,#ec407a pink lighten-1,#e91e63 pink,#d81b60 pink darken-1,#c2185b pink darken-2,#ad1457 pink darken-3,#880e4f pink darken-4,#ff80ab pink accent-1,#ff4081 pink accent-2,#f50057 pink accent-3,#c51162 pink accent-4";
		$purple = "#f3e5f5 purple lighten-5,#e1bee7 purple lighten-4,#ce93d8 purple lighten-3,#ba68c8 purple lighten-2,#ab47bc purple lighten-1,#9c27b0 purple,#8e24aa purple darken-1,#7b1fa2 purple darken-2,#6a1b9a purple darken-3,#4a148c purple darken-4,#ea80fc purple accent-1,#e040fb purple accent-2,#d500f9 purple accent-3,#aa00ff purple accent-4";
		$deep_purple = "#ede7f6 deep-purple lighten-5,#d1c4e9 deep-purple lighten-4,#b39ddb deep-purple lighten-3,#9575cd deep-purple lighten-2,#7e57c2 deep-purple lighten-1,#673ab7 deep-purple,#5e35b1 deep-purple darken-1,#512da8 deep-purple darken-2,#4527a0 deep-purple darken-3,#311b92 deep-purple darken-4,#b388ff deep-purple accent-1,#7c4dff deep-purple accent-2,#651fff deep-purple accent-3,#6200ea deep-purple accent-4";
		$indigo = "#e8eaf6 indigo lighten-5,#c5cae9 indigo lighten-4,#9fa8da indigo lighten-3,#7986cb indigo lighten-2,#5c6bc0 indigo lighten-1,#3f51b5 indigo,#3949ab indigo darken-1,#303f9f indigo darken-2,#283593 indigo darken-3,#1a237e indigo darken-4,#8c9eff indigo accent-1,#536dfe indigo accent-2,#3d5afe indigo accent-3,#304ffe indigo accent-4";
		$blue = "#e3f2fd blue lighten-5,#bbdefb blue lighten-4,#90caf9 blue lighten-3,#64b5f6 blue lighten-2,#42a5f5 blue lighten-1,#2196f3 blue,#1e88e5 blue darken-1,#1976d2 blue darken-2,#1565c0 blue darken-3,#0d47a1 blue darken-4,#82b1ff blue accent-1,#448aff blue accent-2,#2979ff blue accent-3,#2962ff blue accent-4";
		$light_blue = "#e1f5fe light-blue lighten-5,#b3e5fc light-blue lighten-4,#81d4fa light-blue lighten-3,#4fc3f7 light-blue lighten-2,#29b6f6 light-blue lighten-1,#03a9f4 light-blue,#039be5 light-blue darken-1,#0288d1 light-blue darken-2,#0277bd light-blue darken-3,#01579b light-blue darken-4,#80d8ff light-blue accent-1,#40c4ff light-blue accent-2,#00b0ff light-blue accent-3,#0091ea light-blue accent-4";
		$cyan = "#e0f7fa cyan lighten-5,#b2ebf2 cyan lighten-4,#80deea cyan lighten-3,#4dd0e1 cyan lighten-2,#26c6da cyan lighten-1,#00bcd4 cyan,#00acc1 cyan darken-1,#0097a7 cyan darken-2,#00838f cyan darken-3,#006064 cyan darken-4,#84ffff cyan accent-1,#18ffff cyan accent-2,#00e5ff cyan accent-3,#00b8d4 cyan accent-4";
		$teal = "#e0f2f1 teal lighten-5,#b2dfdb teal lighten-4,#80cbc4 teal lighten-3,#4db6ac teal lighten-2,#26a69a teal lighten-1,#009688 teal,#00897b teal darken-1,#00796b teal darken-2,#00695c teal darken-3,#004d40 teal darken-4,#a7ffeb teal accent-1,#64ffda teal accent-2,#1de9b6 teal accent-3,#00bfa5 teal accent-4";
		$green = "#e8f5e9 green lighten-5,#c8e6c9 green lighten-4,#a5d6a7 green lighten-3,#81c784 green lighten-2,#66bb6a green lighten-1,#4caf50 green,#43a047 green darken-1,#388e3c green darken-2,#2e7d32 green darken-3,#1b5e20 green darken-4,#b9f6ca green accent-1,#69f0ae green accent-2,#00e676 green accent-3,#00c853 green accent-4";
		$light_green = "#f1f8e9 light-green lighten-5,#dcedc8 light-green lighten-4,#c5e1a5 light-green lighten-3,#aed581 light-green lighten-2,#9ccc65 light-green lighten-1,#8bc34a light-green,#7cb342 light-green darken-1,#689f38 light-green darken-2,#558b2f light-green darken-3,#33691e light-green darken-4,#ccff90 light-green accent-1,#b2ff59 light-green accent-2,#76ff03 light-green accent-3,#64dd17 light-green accent-4";
		$lime = "#f9fbe7 lime lighten-5,#f0f4c3 lime lighten-4,#e6ee9c lime lighten-3,#dce775 lime lighten-2,#d4e157 lime lighten-1,#cddc39 lime,#c0ca33 lime darken-1,#afb42b lime darken-2,#9e9d24 lime darken-3,#827717 lime darken-4,#f4ff81 lime accent-1,#eeff41 lime accent-2,#c6ff00 lime accent-3,#aeea00 lime accent-4";
		$yellow = "#fffde7 yellow lighten-5,#fff9c4 yellow lighten-4,#fff59d yellow lighten-3,#fff176 yellow lighten-2,#ffee58 yellow lighten-1,#ffeb3b yellow,#fdd835 yellow darken-1,#fbc02d yellow darken-2,#f9a825 yellow darken-3,#f57f17 yellow darken-4,#ffff8d yellow accent-1,#ffff00 yellow accent-2,#ffea00 yellow accent-3,#ffd600 yellow accent-4";
		$amber = "#fff8e1 amber lighten-5,#ffecb3 amber lighten-4,#ffe082 amber lighten-3,#ffd54f amber lighten-2,#ffca28 amber lighten-1,#ffc107 amber,#ffb300 amber darken-1,#ffa000 amber darken-2,#ff8f00 amber darken-3,#ff6f00 amber darken-4,#ffe57f amber accent-1,#ffd740 amber accent-2,#ffc400 amber accent-3,#ffab00 amber accent-4";
		$orange = "#fff3e0 orange lighten-5,#ffe0b2 orange lighten-4,#ffcc80 orange lighten-3,#ffb74d orange lighten-2,#ffa726 orange lighten-1,#ff9800 orange,#fb8c00 orange darken-1,#f57c00 orange darken-2,#ef6c00 orange darken-3,#e65100 orange darken-4,#ffd180 orange accent-1,#ffab40 orange accent-2,#ff9100 orange accent-3,#ff6d00 orange accent-4";
		$deep_orange = "#fbe9e7 deep-orange lighten-5,#ffccbc deep-orange lighten-4,#ffab91 deep-orange lighten-3,#ff8a65 deep-orange lighten-2,#ff7043 deep-orange lighten-1,#ff5722 deep-orange,#f4511e deep-orange darken-1,#e64a19 deep-orange darken-2,#d84315 deep-orange darken-3,#bf360c deep-orange darken-4,#ff9e80 deep-orange accent-1,#ff6e40 deep-orange accent-2,#ff3d00 deep-orange accent-3,#dd2c00 deep-orange accent-4";
		$brown = "#efebe9 brown lighten-5,#d7ccc8 brown lighten-4,#bcaaa4 brown lighten-3,#a1887f brown lighten-2,#8d6e63 brown lighten-1,#795548 brown,#6d4c41 brown darken-1,#5d4037 brown darken-2,#4e342e brown darken-3,#3e2723 brown darken-4";
		$grey = "#fafafa grey lighten-5,#f5f5f5 grey lighten-4,#eeeeee grey lighten-3,#e0e0e0 grey lighten-2,#bdbdbd grey lighten-1,#9e9e9e grey,#757575 grey darken-1,#616161 grey darken-2,#424242 grey darken-3,#212121 grey darken-4";
		$blue_grey = "#eceff1 blue-grey lighten-5,#cfd8dc blue-grey lighten-4,#b0bec5 blue-grey lighten-3,#90a4ae blue-grey lighten-2,#78909c blue-grey lighten-1,#607d8b blue-grey,#546e7a blue-grey darken-1,#455a64 blue-grey darken-2,#37474f blue-grey darken-3,#263238 blue-grey darken-4";
		$b_w_t = "#000000 black,#ffffff white,N/A transparent";
		#[0-13]
		$colors['red'] = explode(",", $red);
		$colors['pink'] = explode(",", $pink);
		$colors['purple'] = explode(",", $purple);
		$colors['deep_purple'] = explode(",", $deep_purple);
		$colors['indigo'] = explode(",", $indigo);
		$colors['blue'] = explode(",", $blue);
		$colors['light_blue'] = explode(",", $light_blue);
		$colors['cyan'] = explode(",", $cyan);
		$colors['teal'] = explode(",", $teal);
		$colors['green'] = explode(",", $green);
		$colors['light_green'] = explode(",", $light_green);
		$colors['lime'] = explode(",", $lime);
		$colors['yellow'] = explode(",", $yellow);
		$colors['amber'] = explode(",", $amber);
		$colors['orange'] = explode(",", $orange);
		$colors['deep_orange'] = explode(",", $deep_orange);
		#[0-9]
		$colors['brown'] = explode(",", $brown);
		$colors['grey'] = explode(",", $grey);
		$colors['blue_grey'] = explode(",", $blue_grey);
		#[0-2]
		$colors['b_w_t'] = explode(",", $b_w_t);
		return $colors;
	}
	public function colors($arg = null){
		$arrayColors = $this->arrayColors();
		$filter_hexa = "/^#([a-f0-9]{3}){1,2}\b\040/";
		foreach ($arrayColors as $key => &$array){
			foreach ($array as $key2 => &$value2){
				preg_match($filter_hexa, $value2, $return);
				$value2 = str_replace($return[0],"",$value2);
			}
		}
		if(empty($arg)){
			return $arrayColors;
		}
		else{
			$key = explode(",", $arg);
			return $arrayColors[$key[0]][$key[1]];
		}
	}
	public function colorsText($arg = null){
		$arrayColors = $this->arrayColors();
		$filter_hexa = "/^#([a-f0-9]{3}){1,2}\b\040/";
		foreach ($arrayColors as $key => &$array){
			foreach ($array as $key2 => &$value2){
				preg_match($filter_hexa, $value2, $return);
				$value2 = str_replace($return[0],"",$value2);			
				if(strripos($value2," ")==0){
					$value2 .= "-text";
				}
				else{
					$value2 = str_replace(" ","-text text-",$value2);
				}				
			}
		}
		if(empty($arg)){
			return $arrayColors;
		}
		else{
			$key = explode(",", $arg);
			return $arrayColors[$key[0]][$key[1]];
		}
	}
	public function colorsHex($arg = null){
		$arrayColors = $this->arrayColors();
		$filter_hexa = "/^#([a-f0-9]{3}){1,2}\b/";
		foreach ($arrayColors as $key => &$array){
			foreach ($array as $key2 => &$value2){
				preg_match($filter_hexa, $value2, $return);
				if(empty($return[0])){
					unset($arrayColors[$key][$key2]);
				}
				else{
					$value2 = str_replace(" ","",$return[0]);
				}
			}
		}
		if(empty($arg)){
			return $arrayColors;
		}
		else{
			$key = explode(",", $arg);
			return $arrayColors[$key[0]][$key[1]];
		}	
	}
	public function icons($arg = null){

		#[0-931]
		$icons = "3d_rotation,ac_unit,access_alarm,access_alarms,access_time,accessibility,accessible,account_balance,account_balance_wallet,account_box,account_circle,adb,add,add_a_photo,add_alarm,add_alert,add_box,add_circle,add_circle_outline,add_location,add_shopping_cart,add_to_photos,add_to_queue,adjust,airline_seat_flat,airline_seat_flat_angled,airline_seat_individual_suite,airline_seat_legroom_extra,airline_seat_legroom_normal,airline_seat_legroom_reduced,airline_seat_recline_extra,airline_seat_recline_normal,airplanemode_active,airplanemode_inactive,airplay,airport_shuttle,alarm,alarm_add,alarm_off,alarm_on,album,all_inclusive,all_out,android,announcement,apps,archive,arrow_back,arrow_downward,arrow_drop_down,arrow_drop_down_circle,arrow_drop_up,arrow_forward,arrow_upward,art_track,aspect_ratio,assessment,assignment,assignment_ind,assignment_late,assignment_return,assignment_returned,assignment_turned_in,assistant,assistant_photo,attach_file,attach_money,attachment,audiotrack,autorenew,av_timer,backspace,backup,battery_alert,battery_charging_full,battery_full,battery_std,battery_unknown,beach_access,beenhere,block,bluetooth,bluetooth_audio,bluetooth_connected,bluetooth_disabled,bluetooth_searching,blur_circular,blur_linear,blur_off,blur_on,book,bookmark,bookmark_border,border_all,border_bottom,border_clear,border_color,border_horizontal,border_inner,border_left,border_outer,border_right,border_style,border_top,border_vertical,branding_watermark,brightness_1,brightness_2,brightness_3,brightness_4,brightness_5,brightness_6,brightness_7,brightness_auto,brightness_high,brightness_low,brightness_medium,broken_image,brush,bubble_chart,bug_report,build,burst_mode,business,business_center,cached,cake,call,call_end,call_made,call_merge,call_missed,call_missed_outgoing,call_received,call_split,call_to_action,camera,camera_alt,camera_enhance,camera_front,camera_rear,camera_roll,cancel,card_giftcard,card_membership,card_travel,casino,cast,cast_connected,center_focus_strong,center_focus_weak,change_history,chat,chat_bubble,chat_bubble_outline,check,check_box,check_box_outline_blank,check_circle,chevron_left,chevron_right,child_care,child_friendly,chrome_reader_mode,class,clear,clear_all,close,closed_caption,cloud,cloud_circle,cloud_done,cloud_download,cloud_off,cloud_queue,cloud_upload,code,collections,collections_bookmark,color_lens,colorize,comment,compare,compare_arrows,computer,confirmation_number,contact_mail,contact_phone,contacts,content_copy,content_cut,content_paste,control_point,control_point_duplicate,copyright,create,create_new_folder,credit_card,crop,crop_16_9,crop_3_2,crop_5_4,crop_7_5,crop_din,crop_free,crop_landscape,crop_original,crop_portrait,crop_rotate,crop_square,dashboard,data_usage,date_range,dehaze,delete,delete_forever,delete_sweep,description,desktop_mac,desktop_windows,details,developer_board,developer_mode,device_hub,devices,devices_other,dialer_sip,dialpad,directions,directions_bike,directions_boat,directions_bus,directions_car,directions_railway,directions_run,directions_subway,directions_transit,directions_walk,disc_full,dns,do_not_disturb,do_not_disturb_alt,do_not_disturb_off,do_not_disturb_on,dock,domain,done,done_all,donut_large,donut_small,drafts,drag_handle,drive_eta,dvr,edit,edit_location,eject,email,enhanced_encryption,equalizer,error,error_outline,euro_symbol,ev_station,event,event_available,event_busy,event_note,event_seat,exit_to_app,expand_less,expand_more,explicit,explore,exposure,exposure_neg_1,exposure_neg_2,exposure_plus_1,exposure_plus_2,exposure_zero,extension,face,fast_forward,fast_rewind,favorite,favorite_border,featured_play_list,featured_video,feedback,fiber_dvr,fiber_manual_record,fiber_new,fiber_pin,fiber_smart_record,file_download,file_upload,filter,filter_1,filter_2,filter_3,filter_4,filter_5,filter_6,filter_7,filter_8,filter_9,filter_9_plus,filter_b_and_w,filter_center_focus,filter_drama,filter_frames,filter_hdr,filter_list,filter_none,filter_tilt_shift,filter_vintage,find_in_page,find_replace,fingerprint,first_page,fitness_center,flag,flare,flash_auto,flash_off,flash_on,flight,flight_land,flight_takeoff,flip,flip_to_back,flip_to_front,folder,folder_open,folder_shared,folder_special,font_download,format_align_center,format_align_justify,format_align_left,format_align_right,format_bold,format_clear,format_color_fill,format_color_reset,format_color_text,format_indent_decrease,format_indent_increase,format_italic,format_line_spacing,format_list_bulleted,format_list_numbered,format_paint,format_quote,format_shapes,format_size,format_strikethrough,format_textdirection_l_to_r,format_textdirection_r_to_l,format_underlined,forum,forward,forward_10,forward_30,forward_5,free_breakfast,fullscreen,fullscreen_exit,functions,g_translate,gamepad,games,gavel,gesture,get_app,gif,golf_course,gps_fixed,gps_not_fixed,gps_off,grade,gradient,grain,graphic_eq,grid_off,grid_on,group,group_add,group_work,hd,hdr_off,hdr_on,hdr_strong,hdr_weak,headset,headset_mic,healing,hearing,help,help_outline,high_quality,highlight,highlight_off,history,home,hot_tub,hotel,hourglass_empty,hourglass_full,http,https,image,image_aspect_ratio,import_contacts,import_export,important_devices,inbox,indeterminate_check_box,info,info_outline,input,insert_chart,insert_comment,insert_drive_file,insert_emoticon,insert_invitation,insert_link,insert_photo,invert_colors,invert_colors_off,iso,keyboard,keyboard_arrow_down,keyboard_arrow_left,keyboard_arrow_right,keyboard_arrow_up,keyboard_backspace,keyboard_capslock,keyboard_hide,keyboard_return,keyboard_tab,keyboard_voice,kitchen,label,label_outline,landscape,language,laptop,laptop_chromebook,laptop_mac,laptop_windows,last_page,launch,layers,layers_clear,leak_add,leak_remove,lens,library_add,library_books,library_music,lightbulb_outline,line_style,line_weight,linear_scale,link,linked_camera,list,live_help,live_tv,local_activity,local_airport,local_atm,local_bar,local_cafe,local_car_wash,local_convenience_store,local_dining,local_drink,local_florist,local_gas_station,local_grocery_store,local_hospital,local_hotel,local_laundry_service,local_library,local_mall,local_movies,local_offer,local_parking,local_pharmacy,local_phone,local_pizza,local_play,local_post_office,local_printshop,local_see,local_shipping,local_taxi,location_city,location_disabled,location_off,location_on,location_searching,lock,lock_open,lock_outline,looks,looks_3,looks_4,looks_5,looks_6,looks_one,looks_two,loop,loupe,low_priority,loyalty,mail,mail_outline,map,markunread,markunread_mailbox,memory,menu,merge_type,message,mic,mic_none,mic_off,mms,mode_comment,mode_edit,monetization_on,money_off,monochrome_photos,mood,mood_bad,more,more_horiz,more_vert,motorcycle,mouse,move_to_inbox,movie,movie_creation,movie_filter,multiline_chart,music_note,music_video,my_location,nature,nature_people,navigate_before,navigate_next,navigation,near_me,network_cell,network_check,network_locked,network_wifi,new_releases,next_week,nfc,no_encryption,no_sim,not_interested,note,note_add,notifications,notifications_active,notifications_none,notifications_off,notifications_paused,offline_pin,ondemand_video,opacity,open_in_browser,open_in_new,open_with,pages,pageview,palette,pan_tool,panorama,panorama_fish_eye,panorama_horizontal,panorama_vertical,panorama_wide_angle,party_mode,pause,pause_circle_filled,pause_circle_outline,payment,people,people_outline,perm_camera_mic,perm_contact_calendar,perm_data_setting,perm_device_information,perm_identity,perm_media,perm_phone_msg,perm_scan_wifi,person,person_add,person_outline,person_pin,person_pin_circle,personal_video,pets,phone,phone_android,phone_bluetooth_speaker,phone_forwarded,phone_in_talk,phone_iphone,phone_locked,phone_missed,phone_paused,phonelink,phonelink_erase,phonelink_lock,phonelink_off,phonelink_ring,phonelink_setup,photo,photo_album,photo_camera,photo_filter,photo_library,photo_size_select_actual,photo_size_select_large,photo_size_select_small,picture_as_pdf,picture_in_picture,picture_in_picture_alt,pie_chart,pie_chart_outlined,pin_drop,place,play_arrow,play_circle_filled,play_circle_outline,play_for_work,playlist_add,playlist_add_check,playlist_play,plus_one,poll,polymer,pool,portable_wifi_off,portrait,power,power_input,power_settings_new,pregnant_woman,present_to_all,print,priority_high,public,publish,query_builder,question_answer,queue,queue_music,queue_play_next,radio,radio_button_checked,radio_button_unchecked,rate_review,receipt,recent_actors,record_voice_over,redeem,redo,refresh,remove,remove_circle,remove_circle_outline,remove_from_queue,remove_red_eye,remove_shopping_cart,reorder,repeat,repeat_one,replay,replay_10,replay_30,replay_5,reply,reply_all,report,report_problem,restaurant,restaurant_menu,restore,restore_page,ring_volume,room,room_service,rotate_90_degrees_ccw,rotate_left,rotate_right,rounded_corner,router,rowing,rss_feed,rv_hookup,satellite,save,scanner,schedule,school,screen_lock_landscape,screen_lock_portrait,screen_lock_rotation,screen_rotation,screen_share,sd_card,sd_storage,search,security,select_all,send,sentiment_dissatisfied,sentiment_neutral,sentiment_satisfied,sentiment_very_dissatisfied,sentiment_very_satisfied,settings,settings_applications,settings_backup_restore,settings_bluetooth,settings_brightness,settings_cell,settings_ethernet,settings_input_antenna,settings_input_component,settings_input_composite,settings_input_hdmi,settings_input_svideo,settings_overscan,settings_phone,settings_power,settings_remote,settings_system_daydream,settings_voice,share,shop,shop_two,shopping_basket,shopping_cart,short_text,show_chart,shuffle,signal_cellular_4_bar,signal_cellular_connected_no_internet_4_bar,signal_cellular_no_sim,signal_cellular_null,signal_cellular_off,signal_wifi_4_bar,signal_wifi_4_bar_lock,signal_wifi_off,sim_card,sim_card_alert,skip_next,skip_previous,slideshow,slow_motion_video,smartphone,smoke_free,smoking_rooms,sms,sms_failed,snooze,sort,sort_by_alpha,spa,space_bar,speaker,speaker_group,speaker_notes,speaker_notes_off,speaker_phone,spellcheck,star,star_border,star_half,stars,stay_current_landscape,stay_current_portrait,stay_primary_landscape,stay_primary_portrait,stop,stop_screen_share,storage,store,store_mall_directory,straighten,streetview,strikethrough_s,style,subdirectory_arrow_left,subdirectory_arrow_right,subject,subscriptions,subtitles,subway,supervisor_account,surround_sound,swap_calls,swap_horiz,swap_vert,swap_vertical_circle,switch_camera,switch_video,sync,sync_disabled,sync_problem,system_update,system_update_alt,tab,tab_unselected,tablet,tablet_android,tablet_mac,tag_faces,tap_and_play,terrain,text_fields,text_format,textsms,texture,theaters,thumb_down,thumb_up,thumbs_up_down,time_to_leave,timelapse,timeline,timer,timer_10,timer_3,timer_off,title,toc,today,toll,tonality,touch_app,toys,track_changes,traffic,train,tram,transfer_within_a_station,transform,translate,trending_down,trending_flat,trending_up,tune,turned_in,turned_in_not,tv,unarchive,undo,unfold_less,unfold_more,update,usb,verified_user,vertical_align_bottom,vertical_align_center,vertical_align_top,vibration,video_call,video_label,video_library,videocam,videocam_off,videogame_asset,view_agenda,view_array,view_carousel,view_column,view_comfy,view_compact,view_day,view_headline,view_list,view_module,view_quilt,view_stream,view_week,vignette,visibility,visibility_off,voice_chat,voicemail,volume_down,volume_mute,volume_off,volume_up,vpn_key,vpn_lock,wallpaper,warning,watch,watch_later,wb_auto,wb_cloudy,wb_incandescent,wb_iridescent,wb_sunny,wc,web,web_asset,weekend,whatshot,widgets,wifi,wifi_lock,wifi_tethering,work,wrap_text,youtube_searched_for,zoom_in,zoom_out,zoom_out_map";
		$icons = explode(",", $icons);
		if(is_null($arg)){
			return $icons;
		}
		else{
			return $icons[$arg];			
		}
	}
	public function hover($arg = null){
		$class = " hoverable ";
		if($arg){
			return $class;
		}
		else{
			return false;			
		}				
	}
	public function iconSize($arg = null){
		$icons_size = "tiny,small,medium,large";
		$icons_size = explode(",", $icons_size);
		if(is_null($arg)){
			return $icons_size;
		}
		else{
			return $icons_size[$arg];			
		}				
	}	
	public function shadow($arg = null){
		$shadow = "z-depth-1,z-depth-2,z-depth-3,z-depth-4,z-depth-5";
		$shadow = explode(",", $shadow);
		if(is_null($arg)){
			return $shadow;
		}
		else{
			return $shadow[$arg];			
		}					
	}	
	public function valing($arg = null){
		$class = " valing ";
		if($arg){
			return $class;
		}
		else{
			return false;			
		}				
	}
	public function flowText($arg = null){
		$class = " flow-text ";
		if($arg){
			return $class;
		}
		else{
			return false;			
		}				
	}
	public function align($arg = null){
		$align = "left-align,center-align,right-align";
		$align = explode(",", $align);
		if(is_null($arg)){
			return $align;
		}
		else{
			return $align[$arg];			
		}					
	}
	public function scaleTransition($arg = null){
		$align = "scale-transition scale-in,scale-transition scale-out";
		$align = explode(",", $align);
		if(is_null($arg)){
			return $align;
		}
		else{
			return $align[$arg];			
		}		
	}		
	public function float($arg = null){
		$float   ="left,right";
		$float  = explode(",", $float);
		if(is_null($arg)){
			return $float;
		}
		else{
			return $float[$arg];			
		}					
	}
	/**
	 * [waves description] -
	 * @param  ( null | integer | string ) $arg [description] - Si $arg es de tipo 'null' retorna un array defaultWaves, 
	 *                											Si $arg es de tipo 'integer'[0-7] retorna un string defaultWaves.
	 *                											Si $arg es de tipo 'string' con valor 'circle' retorna un array circleWaves. 
	 *                											Si $arg es de tipo 'string' con valor 'circle, integer' (integer[0-7]) 
	 *                											retorna un string circleWaves. 
	 * @return ( array | string )      [description] - retorna defaultWaves o circleWaves
	 */
	public function waves($arg = null){
		$defaultWaves = "waves-effect";
		$circleWaves = "waves-circle";
		#[0-7]
		$waveColors = "waves-light,waves-red,waves-yellow,waves-orange,waves-purple,waves-green,waves-teal";
		$arrayWaves = explode(",", $waveColors);
		if (empty($arg) || is_numeric($arg)) {
			$waves[] = "{$defaultWaves}";
			foreach ($arrayWaves as $value){
				$waves[] = "{$defaultWaves} {$value}";
			}
			if(is_null($arg)){
				# null = defaultWaves default
				return $waves;
			}
			else{
				# integer = defaultWaves default key [0-7]
				if(preg_match('#[0-7]{1}$#', $arg, $k)){
					$arg = $k[0]; 
					return $waves[$arg];
				}			
			}
		}
		elseif (is_string($arg)) {
			$waves[] = "{$defaultWaves} {$circleWaves}";
			foreach ($arrayWaves as $value){
				$waves[] = "{$defaultWaves} {$circleWaves} {$value}";
			}			
			if(strpos($arg, ',') == false){
				# string = circleWaves
				if($arg == 'circle'){
					return $waves;
				}
			}
			else{		
				# string = circleWaves key [0-7]
				$key  = explode(",", $arg);
				if(preg_match('#[0-7]{1}$#', $key[1], $k)){			
					$key[1] = $k[0];
					if($key[0] == 'circle'){
						return $waves[$key[1]];
					}
				}
			}
		}
	}
}