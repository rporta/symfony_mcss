<?php 

/**
* 
*/
class p extends createClass
{
	public $_name;
	public $_text;
	public $_textColor;
	public $_backgroundColor;
	public $_align;
	public $_html;
	public $_searchData;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'text':
						$this->_text = !empty($value) ? $value : "";
						break;
					case $key == 'align':
						$this->_align = !empty($value) && $value<=3 && $value>=0   ? $value : "0";
						break;
				}
			}
		}
		## set html
		$this->setHtml();
	}
	public function setHtml(){
		$outHtml = "<p class='{class}'>{text}</p>";
		$search[] = "{class}";
		$search[] = "{text}";
		if($this->_align == ""){
			$align = "";
		}
		else{
			$align = $this->align($this->_align);
		}		
		$replace[] = "{$this->_backgroundColor} {$this->_textColor} {$align}";
		$replace[] = "{$this->_text}";
		$this->_html = str_replace($search, $replace, $outHtml);		
	}
}