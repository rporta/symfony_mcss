<?php 

/**
* 
*/
class table extends createClass
{
	public $_name;
	public $_type;
	public $_textColor;
	public $_backgroundColor;
	public $_center;
	public $_head;
	public $_row;
	public $_html;
	public $_searchData;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set type
			if (empty($this->_searchData['type'])){ 
				$this->setType();
			}
			else {
				$this->setType($this->_searchData['type']);
			}
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set head
			if (empty($this->_searchData['head'])){ 
				$this->_head = false;
			}
			else {
				$this->_head = $this->_searchData['head'];
			}
			## set row
			if (empty($this->_searchData['row'])){ 
				$this->_row = false;
			}
			else {
				$this->_row = $this->_searchData['row'];
			}
			## set center
			if (empty($this->_searchData['center'])){ 
				$this->_center = false;
			}
			else {
				$this->_center = $this->_searchData['center'];
			}			
		}
		## setHtml
		$this->setHtml();

	}
	public function setHtml(){
		if($this->_type == 'Table'){
			$type = " ";
		}
		elseif($this->_type == 'Striped Table'){
			$type = " striped ";
		}
		elseif($this->_type == 'Highlight Table'){
			$type = " highlight ";
		}
		elseif($this->_type == 'Responsive Table'){
			$type = " responsive-table ";
		}

		$outHtml =
		"<table class='{$type} {class}' >
			<thead><tr>{head}</tr>
			</thead>
			<tbody>{row}
			</tbody>
		</table>";
		$search[] = "{class}";
		$class = "";
		if($this->_backgroundColor !== false ){$class .= " {$this->colors($this->_backgroundColor)} ";}
		if($this->_textColor !== false ){$class .= " {$this->colorsText($this->_textColor)} ";}
		if($this->_center !== false ){$class .= " centered ";}
		$replace[] = "{$class} ";
		$search[] = "{head}";
		$search[] = "{row}";

		foreach ($this->_head as $col) {
			$head[] = "<th>{$col}</th>";
		}
		unset($col);
		$replace[] = implode("", $head);
		foreach ($this->_row as $array) {
			foreach ($array as $value) {
				$row[] = "<td>{$value}</td>";
			}
			$reg[]= "<tr>".implode("", $row)."</tr>";
			unset($row);
		}
		$replace[] = implode("", $reg);

		$this->_html = str_replace($search, $replace, $outHtml);		
	}
	public function setType($arg = null){
		switch (1) {
			case $arg == 0:
				$this->_type = 'Table';
				break;
			case $arg == 1:
				$this->_type = 'Striped Table';
				break;
			case $arg == 2:
				$this->_type = 'Highlight Table';
				break;
			case $arg == 3:
				$this->_type = 'Responsive Table';
				break;
			default:
				$this->_type = 'Table';
				break;
		}	
	}
}