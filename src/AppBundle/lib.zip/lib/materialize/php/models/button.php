<?php 
/**
 * btnFlat  (boolean)
 * btnFloating (boolean)
 * btnDisabled (boolean)
 * btnLarge (boolean)
 * btnSubmit (boolean)
 */
class button extends createClass
{
	public $_name;
	public $_type;
	public $_effect;
	public $_textColor;
	public $_backgroundColor;
	public $_text;
	public $_btnFlat;
	public $_btnFloating;
	public $_btnDisabled;
	public $_btnLarge;
	public $_btnSubmit;
	public $_obj;//icon
	public $_href;
	public $_float;

	public $_html;
	public $_js;
	public $_searchData;
	
	public function __construct($array){
		$this->refreshInfo($array);
	}
	public function refreshInfo($array){
		$this->_searchData = $array;
		foreach ($array as $key => $value) {
			switch (1) {
				case $key == 'name':
				$this->_name = !empty($value) ? $this->createId($value) : "";
				break;
				case $key == 'type':
				switch ($value) {
					case 'default':
						$this->_type = "default";
						break;
					case 'vFab':
						$this->_type = "vFab";
						break;
					case 'hFab':
						$this->_type = "hFab";
						break;
					case 'vToggleClickFab':
						$this->_type = "vToggleClickFab";
						break;
					case 'hToggleClickFab':
						$this->_type = "hToggleClickFab";
						break;
					case 'toolBarFab':
						$this->_type = "toolBarFab";
						break;
				}	
				break;
				case $key == 'effect':
					$this->_effect = !is_null($value) ? $this->waves($value) : "";
					break;
				case $key == 'textColor':
					$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
					break;
				case $key == 'backgroundColor':
					$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
					break;
				case $key == 'text':
					$this->_text = !empty($value) ? $value : "";
					break;
				case $key == 'dataTarget':
					$this->_dataTarget = !empty($value) ? $value : "";
					break;
				case $key == 'btnFlat':
					$this->_btnFlat = $value ? " btn-flat " : "";
					break;
				case $key == 'btnFloating':
					$this->_btnFloating = $value ? " btn-floating " : "";
					break;
				case $key == 'btnDisabled':
					$this->_btnDisabled = $value ? " disabled " : "";
					break;
				case $key == 'btnLarge':
					$this->_btnLarge = $value ? " btn-large " : "";
					break;
				case $key == 'btnSubmit':
					$this->_btnSubmit = $value ? " type='submit' name='{$this->_name}' " : "";
					break;
				case $key == 'href':
					$this->_href = !empty($value) ? " href='{$value}' " : "";
					break;
				case $key == 'float':
					$this->float = $value;
					break;
				case $key == 'js':
					switch ($value) {
						case 'openFab':
							$this->_js = !empty($value) ? "$('.fixed-action-btn').openFAB();" : "";
							break;
						case 'closeFab':
							$this->_js = !empty($value) ? "$('.fixed-action-btn').closeFAB();" : "";
							break;						
						case 'openToolbarFab':
							$this->_js = !empty($value) ? "$('.fixed-action-btn.toolbar').openToolbar();" : "";
							break;
						case 'closeToolbarFab':
							$this->_js = !empty($value) ? "$('.fixed-action-btn.toolbar').closeToolbar();" : "";
							break;
					}
					break;
				case $key == 'obj':
					if(is_array($value)){
						foreach ($value as $key3 => $value3) {
							if($value3 instanceof icon){
								$this->_obj[] = $value3;
							}
						}
					}
					else{
						$this->_obj[] = $value;
					}
					break;
			}
		}
		switch ($this->_type) {
			case 'default':
				$outHtml = $this->defautBtn();
				break;
			case 'vFab':
				$outHtml = $this->vFab();
				break;
			case 'hFab':
				$outHtml = $this->hFab();
				break;
			case 'vToggleClickFab':
				$outHtml = $this->vToggleClickFab();
				break;
			case 'hToggleClickFab':
				$outHtml = $this->hToggleClickFab();
				break;
			case 'toolBarFab':
				$outHtml = $this->toolBarFab();
				break;
		}
		$this->_html = $outHtml;
	}
	public function vFab(){
		#search: {class}, {param}, {obj}, {text}
		$this->_btnFloating = " btn-floating ";
		$defaultBtn = $this->defautBtn();
		$defaultBtn = str_replace("<a class='btn", "<a class='", $defaultBtn);
		foreach ($this->_obj as $key => $value) {
			if($key > 0){
				$obj = "<li><a class='{class} {classObj}' href='{hrefObj}'>{htmlObj}</a></li>";
				$search[] = "{class}";
				$search[] = "{classObj}";
				$search[] = "{hrefObj}";
				$search[] = "{htmlObj}";
				if(!is_null($this->_btnLarge)){
					$replace[] = "{$this->_btnLarge} {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";	
				}
				else{
					$replace[] = " {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";					
				}
				$replace[] = "{$value->_effect} {$value->_backgroundColor} {$this->_btnFloating}";
				$replace[] = $value->_href;
				$replace[] = $value->_html;

				$objHtml .= str_replace($search, $replace, $obj);
				unset($search);		
				unset($replace);		
			}
		}
		$outHtml = 
		"<div class='fixed-action-btn'>
			{$defaultBtn}
			<ul>
				{$objHtml}
			</ul>
		</div>";
		return $outHtml;
	}	 
	public function hFab(){
		#search: {class}, {param}, {obj}, {text}
		$this->_btnFloating = " btn-floating ";
		$defaultBtn = $this->defautBtn();
		$defaultBtn = str_replace("<a class='btn", "<a class='", $defaultBtn);
		foreach ($this->_obj as $key => $value) {
			if($key > 0){
				$obj = "<li style='margin:0px 15px 0px 0px ;'><a class='{class} {classObj}' href='{hrefObj}'>{htmlObj}</a></li>";
				$search[] = "{class}";
				$search[] = "{classObj}";
				$search[] = "{hrefObj}";
				$search[] = "{htmlObj}";
				if(is_null($this->_btnLarge) || $this->_btnLarge == false){
					$replace[] = " {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";	
				}
				else{
					$replace[] = "{$this->_btnLarge} {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";					
				}
				$replace[] = "{$value->_effect} {$value->_backgroundColor} {$this->_btnFloating}";
				$replace[] = $value->_href;
				$replace[] = $value->_html;

				$objHtml .= str_replace($search, $replace, $obj);
				unset($search);		
				unset($replace);		
			}
		}
		$outHtml = 
		"<div class='fixed-action-btn horizontal'>
			{$defaultBtn}
			<ul>
				{$objHtml}
			</ul>
		</div>";
		return $outHtml;
	} 
	public function vToggleClickFab(){
		$this->_btnFloating = " btn-floating ";
		$defaultBtn = $this->defautBtn();
		$defaultBtn = str_replace("<a class='btn", "<a class='", $defaultBtn);
		foreach ($this->_obj as $key => $value) {
			if($key > 0){
				$obj = "<li><a class='{class} {classObj}' href='{hrefObj}'>{htmlObj}</a></li>";
				$search[] = "{class}";
				$search[] = "{classObj}";
				$search[] = "{hrefObj}";
				$search[] = "{htmlObj}";
				if(!is_null($this->_btnLarge)){
					$replace[] = "{$this->_btnLarge} {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";	
				}
				else{
					$replace[] = " {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";					
				}
				$replace[] = "{$value->_effect} {$value->_backgroundColor} {$this->_btnFloating}";
				$replace[] = $value->_href;
				$replace[] = $value->_html;

				$objHtml .= str_replace($search, $replace, $obj);
				unset($search);		
				unset($replace);		
			}
		}
		$outHtml = 
		"<div class='fixed-action-btn click-to-toggle'>
			{$defaultBtn}
			<ul>
				{$objHtml}
			</ul>
		</div>";
		return $outHtml;
	}	
	public function hToggleClickFab(){
		$this->_btnFloating = " btn-floating ";
		$defaultBtn = $this->defautBtn();
		$defaultBtn = str_replace("<a class='btn", "<a class='", $defaultBtn);
		foreach ($this->_obj as $key => $value) {
			if($key > 0){
				$obj = "<li style='margin:0px 15px 0px 0px ;'><a class='{class} {classObj}' href='{hrefObj}'>{htmlObj}</a></li>";
				$search[] = "{class}";
				$search[] = "{classObj}";
				$search[] = "{hrefObj}";
				$search[] = "{htmlObj}";
				if(is_null($this->_btnLarge) || $this->_btnLarge == false){
					$replace[] = " {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";	
				}
				else{
					$replace[] = "{$this->_btnLarge} {$this->_textColor} {$this->_btnFlat} {$this->floating} {$this->_btnDisabled} ";					
				}
				$replace[] = "{$value->_effect} {$value->_backgroundColor} {$this->_btnFloating}";
				$replace[] = $value->_href;
				$replace[] = $value->_html;

				$objHtml .= str_replace($search, $replace, $obj);
				unset($search);		
				unset($replace);		
			}
		}
		$outHtml = 
		"<div class='fixed-action-btn click-to-toggle horizontal'>
			{$defaultBtn}
			<ul>
				{$objHtml}
			</ul>
		</div>";
		return $outHtml;
	}
	public function toolBarFab(){
		$this->_btnFloating = " btn-floating ";
		$this->_text = ""; 
		$defaultBtn = $this->defautBtn();
		foreach ($this->_obj as $key => $value) {
			if($key > 0){
				$value->_size = "";
				$value->refreshInfo();
				$obj = "<li class='{class} {classObj}' ><a href='{hrefObj}'>{htmlObj}</a></li>";
				$search[] = "{class}";
				$search[] = "{classObj}";
				$search[] = "{hrefObj}";
				$search[] = "{htmlObj}";



				$replace[] = "{$this->_btnDisabled}";
				$replace[] = "{$value->_effect} {$value->_backgroundColor}";
				$replace[] = $value->_href;
				$replace[] = $value->_html;

				$objHtml .= str_replace($search, $replace, $obj);
				unset($search);		
				unset($replace);		
			}
		}		
		$outHtml = 
		"<div class='fixed-action-btn toolbar'>
			{$defaultBtn}
			<ul>
				{$objHtml}
			</ul>
		</div>";
		return $outHtml;
	}
	public function defautBtn(){
		$float = "";
		if(!empty($this->float) || $this->float == 0){
			$float = $this->float($this->float);
			if(is_array($float)) $float = "";
		}
		if(!empty($this->_dataTarget)){
			$dTarget = " sidenav-trigger ";
			$pDatarget = " data-target='{$this->_dataTarget}' ";
		}
		else{
			$dTarget = "";
			$pDatarget = "";
		}

		$class = "{$dTarget} {$float} {$this->_effect} {$this->_textColor} {$this->_backgroundColor} {$this->_btnFlat} {$this->_btnFloating} {$this->_btnDisabled} {$this->_btnLarge} ";
		$param = "{$pDatarget} {$this->_btnSubmit} {$this->_href}";
		if (!is_null($this->_obj[0]->_float)){	
			$this->_obj[0]->_float = "left";
			$this->_obj[0]->refreshInfo();
		}
		$obj = $this->_obj[0]->_html;
		$text = $this->_text;
		$search[] = "{class}";
		$search[] = "{obj}";
		$search[] = "{text}";

		$replace[] = $class;
		$replace[] = $obj;
		$replace[] = $text;

		if( $this->_btnSubmit == true){
			$search[] = "<a";
			$search[] = "a>";			
			$replace[] = "<button";
			$replace[] = "button>";
		}

		$outHtml = "<a class='btn {class}' {$param} >{obj}{text}</a>";
		$outHtml = str_replace($search, $replace, $outHtml);
		return $outHtml;
	}
}
?>
