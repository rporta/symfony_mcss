<?php 

/**
* 
*/
class collections extends createClass
{
	public $_name;
	public $_textColor;
	public $_backgroundColor;
	public $_valing;
	public $_align;
	public $_center;
	public $_z;
	public $_obj;
	
	public $_js;
	public $_html;
	public $_searchData;

	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set style
			if (empty($this->_searchData['style'])){ 
				$this->_style = false;
			}
			else {
				$this->_style = $this->_searchData['style'];
			}
			## set valing
			if (empty($this->_searchData['valing'])){ 
				$this->_valing = false;
			}
			else {
				$this->_valing = $this->_searchData['valing'];
			}
			## set align
			if (empty($this->_searchData['align'])){ 
				$this->_align = false;
			}
			else {
				$this->_align = $this->_searchData['align'];
			}
			## set center
			if (empty($this->_searchData['center'])){ 
				$this->_center = false;
			}
			else {
				$this->_center = $this->_searchData['center'];
			}
			## set obj
			if (!empty($this->_searchData['obj'])){ 
				$this->_obj = $this->_searchData['obj'];
			}
			elseif(!empty($this->_obj)){
				$this->_obj = $this->_obj;
			}
			else {
				$this->_obj = false;
			}
			## set js
			if (!empty($this->_searchData['obj']) ){ 
				$this->_obj = $this->_searchData['obj'];
				foreach ($this->_obj as $obj){
					$js[] = " {$obj->_js} ";
				}
				$this->_js = $js;
			}
			elseif(!empty($this->_obj)){
				$this->_obj = $this->_obj;
				foreach ($this->_obj as $obj){
					$js[] = " {$obj->_js} ";
				}
				$this->_js = $js;
			}
			else {
				$this->_js = false;
			}
			## set z
			if (empty($this->_searchData['z'])){ 
				$this->_z = false;
			}
			else {
				$this->_z = $this->_searchData['z'];
			}
			## set width
			if (empty($this->_searchData['width'])){ 
				$this->_width = false;
			}
			else {
				$this->_width = $this->_searchData['width'];
			}
			## set height
			if (empty($this->_searchData['height'])){
				$this->_height = false;
			}
			else {
				$this->_height = $this->_searchData['height'];
			}
			## set absolute
			if (empty($this->_searchData['absolute'])){
				$this->_absolute = false;
			}
			else {
				$this->_absolute = $this->_searchData['absolute'];
			}
		}
		## set html
		$this->setHtml();
	}
	public function setHtml(){
		$name = "";
		if($this->_name !== false){ $name = " name='{$this->_name}' ";}	
		if($this->_style == false){	
			if($this->_center)
				$style = " position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); ";
			else{
				$style = "";
			}
			if($this->_z !== false){
				$style .= " z-index: {$this->_z}; ";
			}
			if($this->_width !== false){
				$style .= " width: {$this->_width}%; ";
			}

			if($this->_height !== false){
				
				$style .= " height: {$this->_height}%; ";
			}
			if($this->_absolute !== false){
				
				$style .= " position: absolute; overflow: hidden;";
			}
		}
		else{
			$style = $this->_style;
		}
		$outHtml = "<ul class='collection {class}' style='{$style}' {$name}>{obj}</ul>";
		$search[] = "{class}";

		if($this->_align == ""){
			$align = "";
		}
		else{
			$align = $this->align($this->_align);
		}
		if($this->_valing){
			$valing = $this->valing($this->_valing);
		}
		else{
			$valing = "";
		}

		$rp = "";
		if($this->_backgroundColor !== false){
			$rp .= " {$this->colors($this->_backgroundColor)} ";
		}
		if($this->_textColor !== false){
			$rp .= " {$this->colorsText($this->_textColor)} ";
		}

		$replace[] = "{$rp} {$align} {$valing}";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = str_replace("class='", "class=' collection-item ", $value->_html);
			}
			$replace[] = implode(" ", $obj);
		}
		elseif($this->obj == false){
			$search[] = "{obj}";
			$replace[] = "";
		}
		$this->_html = str_replace($search, $replace, $outHtml);
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
				$this->_js[] = $value->_js;
			}
		}
		else{
			$this->_obj[] = $arg;
			$this->_js[] = $arg->_js;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}