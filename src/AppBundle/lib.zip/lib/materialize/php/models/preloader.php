<?php

class preloader extends createClass
{
	public $_name;
	public $_type;
	public $_width;
	public $_size;
	public $_backgroundColor;
	
	public $_html;
	public $_js;
	public $_searchData;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set type
			if (empty($this->_searchData['type'])){ 
				$this->setType();
			}
			else {
				$this->setType($this->_searchData['type']);
			}
			## set width
			if (empty($this->_searchData['width'])){ 
				$this->_width = false;
			}
			else {
				$this->_width = $this->_searchData['width'];
			}
			## set size
			if (empty($this->_searchData['size'])){ 
				$this->_size = false;
			}
			else {
				$this->_size = $this->_searchData['size'];
			}		
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set js
			if (empty($this->_searchData['name'])){ 
				$this->_js = false;
			}
			else {
				$effect =  "fadeOut(500)";
				// $effect =  "addClass('{$this->scaleTransition(1)}')";
				$code = " $(\"div[name='{$this->_name}']\").{$effect}; ";
				$this->_js = 
				" setTimeout(function(){".$code."},1000); ";
			}
		}

		## set html
		$this->setHtml();
	}
	public function setHtml(){
		if($this->_type == "Linear"){
			$temp = 
			"<div class='{param_1}'>
			    <div {param_2}></div>
			</div>";
			if($this->_width == false){
				$search[] = "{param_1}";
				$search[] = "{param_2}";
				$replace[] = "{$this->colors($this->_backgroundColor[0])} progress";
				$replace[] = "class='{$this->colors($this->_backgroundColor[1])} indeterminate'";
				$this->_html = str_replace($search, $replace, $temp);
			}
			else{
				$search[] = "{param_1}";
				$search[] = "{param_2}";
				$replace[] = "{$this->colors($this->_backgroundColor[0])} progress";
				$replace[] = "class='{$this->colors($this->_backgroundColor[1])} determinate' style='width: {$this->_width}%'";
				$this->_html = str_replace($search, $replace, $temp);
			}
		}
		elseif($this->_type == "Circular"){
			$temp =
			"<div class='preloader-wrapper {size} active'>
				{objBackgroundColor}
			</div>";
			$search[] = "{size}";
			$search[] = "{objBackgroundColor}";

			$size = " small ,  , big ";
			$arraySize = explode(",", $size);

			if($this->_size == false){
				$replace[] = $arraySize[1];
			}
			else{
				$replace[] = $arraySize[$this->_size];
			}
			$objBackgroundColor =
				"<div class='spinner-layer spinner-{$this->colors($this->_backgroundColor[0])}-only'>
					<div class='circle-clipper left'>
						<div class='circle'></div>
					</div><div class='gap-patch'>
						<div class='circle'></div>
					</div><div class='circle-clipper right'>
						<div class='circle'></div>
					</div>
				</div>";				
			$replace[] = $objBackgroundColor;
			$this->_html = str_replace($search, $replace, $temp);
		}
		elseif($this->_type == "circularFlashingColors"){
			$temp =
			"<div class='preloader-wrapper {size} active'>
				{objBackgroundColor}
			</div>";

			$search[] = "{size}";
			$search[] = "{objBackgroundColor}";

			$size = " small ,  , big ";
			$arraySize = explode(",", $size);

			if($this->_size == false){
				$replace[] = $arraySize[1];
			}
			else{
				$replace[] = $arraySize[$this->_size];
			}

			foreach ($this->_backgroundColor as $backgroundColor) {
				$objBackgroundColor[] = 
				"<div class='spinner-layer spinner-{$this->colors($backgroundColor)}'>
					<div class='circle-clipper left'>
						<div class='circle'></div>
					</div>
					<div class='gap-patch'>
						<div class='circle'></div>
					</div>
					<div class='circle-clipper right'>
						<div class='circle'></div>
					</div>
				</div>";
			}
			$replace[] = implode("", $objBackgroundColor);
			$this->_html = str_replace($search, $replace, $temp);			
		}
	}
	public function setType($arg = null){
		switch (1) {
			case $arg == 0:
				$this->_type = 'Linear';
				break;
			case $arg == 1:
				$this->_type = 'Circular';
				break;
			case $arg == 2:
				$this->_type = 'circularFlashingColors';
				break;
			default:
				$this->_type = 'Linear';
				break;
		}	
	}
}