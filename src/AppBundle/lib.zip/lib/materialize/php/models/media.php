<?php 

class media extends createClass
{
	public $_name;
	public $_type;
	public $_src;
	public $_alt;

	public $_circle;
	public $_responsive;
	public $_embeds;
	
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set type
			if (empty($this->_searchData['type'])){ 
				$this->setType();
			}
			else {
				$this->setType($this->_searchData['type']);
			}
			## set src
			if (empty($this->_searchData['src'])){ 
				$this->_src = false;
			}
			else {
				$this->_src = $this->_searchData['src'];
			}
			## set alt
			if (empty($this->_searchData['alt'])){ 
				$this->_alt = false;
			}
			else {
				$this->_alt = $this->_searchData['alt'];
			}
			## set circle
			if (empty($this->_searchData['circle'])){ 
				$this->_circle = false;
			}
			else {
				$this->_circle = $this->_searchData['circle'];
			}
			## set responsive
			if (empty($this->_searchData['responsive'])){ 
				$this->_responsive = false;
			}
			else {
				$this->_responsive = $this->_searchData['responsive'];
			}
			## set embeds
			if (empty($this->_searchData['embeds'])){ 
				$this->_embeds = false;
			}
			else {
				$this->_embeds = $this->_searchData['embeds'];
			}
		}
		## set html
		$this->setHtml();
	}
	public function setType($arg = null){
		switch (1) {
			case $arg == 0:
				$this->_type = 'Images';
				break;
			case $arg == 1:
				$this->_type = 'Videos';
				break;
			default:
				$this->_type = 'Images';
				break;
		}
	}
	public function setHtml(){
		if ($this->_type == 'Images'){
			$temp = "<img class='{class}' src='{src}' {alt}>";
			$alt = '';
			$class = '';
			$src = '';
			if($this->_alt){ $alt .= "alt='{$this->name}'"; }
			if($this->_circle){ $class .= ' circle  '; }
			if($this->_responsive){ $class .= ' responsive-img '; }
			if(!empty($this->_src)){ $src .= $this->_src; }

			$search[] = '{alt}';
			$search[] = '{class}';
			$search[] = '{src}';
			$replace[] = $alt;
			$replace[] = $class;
			$replace[] = $src;

			$this->_html = str_replace($search, $replace, $temp);
		}
		elseif ($this->_type == 'Videos'){
			if ($this->_embeds == false){

				$temp = 
				"<video class='responsive-video' controls>
					<source src='{src}' type='video/mp4'>
				</video>";
				$search[] = '{src}';
				$replace[] = '{$src}';

				$this->_html = str_replace($search, $replace, $temp);
			}
			else{

				$temp = 
				"<div class='video-container'>
					<iframe src='{src}' frameborder='0' allowfullscreen></iframe>
				</div>";
				$search[] = '{src}';
				$replace[] = '{$src}';

				$this->_html = str_replace($search, $replace, $temp);
			}
		}
	}
}