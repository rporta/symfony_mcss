<?php

/**
* 
*/
class icon extends createClass
{
	public $_name;
	public $_size;
	public $_icon;
	public $_textColor;
	public $_float;

	public $_backgroundColor;
	public $_href;
	public $_effect;

	public $_html;
	public $_searchData;

	function __construct($array)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'size': 
						$this->_size = (!is_null($value)) ? $this->iconSize($value) : "";
						break;
					case $key == 'icon':
						$this->_icon = !is_null($value) ? $this->icons($value) : "";
						break;
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'effect':
						$this->_effect = !is_null($value) ? $this->waves($value) : "";
						break;
					case $key == 'href':
						$this->_href = !empty($value) ? $value : "";
						break;	
					case $key == 'float':

						$this->_float = !is_null($value) ? $this->float($value) : "0";
						break;	
				}
			}
		}
		
		$outHtml = "<i class='material-icons {class}'>{ico}</i>";
		$search[] = "{class}";
		$search[] = "{ico}";

		$replace[] = "{$this->_size} {$this->_textColor} {$this->_float}";
		$replace[] = "{$this->_icon}";		
		$this->_html = str_replace($search, $replace, $outHtml);
	}
}