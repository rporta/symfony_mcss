<?php

class divider extends createClass
{
	public $_name;
	public $_backgroundColor;
	public $_html;
	public $_searchData;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;	
				}
			}
		}
		$outHtml = "<div class='divider {class}'></div>";
		$search[] = "{class}";

		$replace[] = "{$this->_backgroundColor}";	
		$this->_html = str_replace($search, $replace, $outHtml);
	}
}