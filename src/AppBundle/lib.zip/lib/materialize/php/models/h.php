<?php 

/**
* 
*/
class h extends createClass
{
	public $_name;
	public $_text;
	public $_size = 1;
	public $_textColor;
	public $_backgroundColor;
	public $_align;
	public $_html;
	public $_searchData;
	
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'name':
						$this->_name = !empty($value) ? $this->createId($value) : "";
						break;
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'text':
						$this->_text = !empty($value) ? $value : "";
						break;
					case $key == 'size':
						$this->_size = !empty($value) && $value<=5 && $value>=1   ? $value : "1";
						break;
					case $key == 'align':
						$this->_align = !empty($value) && $value<=3 && $value>=0   ? $value : "0";
						break;
				}
			}
		}
		$outHtml = "<h{$this->_size} class='{class}' style='word-break: break-all;word-wrap: break-word;'>{obj}{text}</h{$this->_size}>";
		$search[] = "{class}";
		$search[] = "{text}";

		if($this->_align == ""){
			$align = "";
		}
		else{
			$align = $this->align($this->_align);
		}
		$replace[] = "{$this->_backgroundColor} {$this->_textColor} {$align}";
		$replace[] = "{$this->_text}";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = $value->_html;
			}
			$replace[] = implode(" ", $obj);
		}
		else{
			$search[] = "{obj}";
			$replace[] = "";
		}
		$this->_html = str_replace($search, $replace, $outHtml);
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
			}
		}
		else{
			$this->_obj[] = $arg;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}