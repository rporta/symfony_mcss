<?php 

/**
* 
*/
class form extends createClass
{
	public $_name;
	public $_textColor;
	public $_backgroundColor;
	public $_html;
	public $_js;
	public $_obj;
	public $_searchData;
	public $_valing = false;
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			
			## set action 
			if (empty($this->_searchData['action'])){ 
				$this->_action = false;
			}
			else {
				$this->_action = $this->_searchData['action'];
			}
			## set method 
			if (empty($this->_searchData['method'])){ 
				$this->_method = false;
			}
			else {
				$this->_method = $this->_searchData['method'];
			}
			## set file
			if (empty($this->_searchData['file'])){ 
				$this->_file = false;
			}
			else {
				$this->_file = $this->_searchData['file'];
			}
			## set name
			if (empty($this->_searchData['name'])){ 
				$this->_name = false;
			}
			else {
				$this->_name = $this->_searchData['name'];
			}
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set obj
			if (!empty($this->_searchData['obj'])){ 
				$this->_obj = $this->_searchData['obj'];
			}
			elseif(!empty($this->_obj)){
				$this->_obj = $this->_obj;
			}
			else {
				$this->_obj = false;
			}
		}
		## set html
		$this->setHtml();
	}
	public function setHtml(){
		$method = " method='GET' ";
		$action = "";
		$file = "";
		$backgroundColor = "";
		$textColor = "";

		if($this->_method !== false){ $method = " method='{$this->_method}' "; }
		if($this->_action !== false){ $action = " action='{$this->_action}' "; }
		if($this->_file !== false){ $file = " enctype='multipart/form-data' "; }

		$outHtml = "<form {$action} {$file} {$method} class='{class}'>{obj}</form>";
		$search[] = "{class}";

		if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor);}
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor);}
		if($this->_align == ""){
			$align = "";
		}
		else{
			$align = $this->align($this->_align);
		}
		if($this->_valing){
			$valing = "valign-wrapper";
		}
		else{
			$valing = "";
		}
		$replace[] = "{$backgroundColor} {$textColor} {$align} {$valing}";
		if (is_array($this->_obj)){
			$search[] = "{obj}";
			foreach ($this->_obj as $key => $value) {
				$obj[] = $value->_html;
			}
			$replace[] = implode(" ", $obj);
		}
		else if($this->_obj == ""){
			$search[] = "{obj}";
			$replace[] = "";
		}	

		$this->_html = str_replace($search, $replace, $outHtml);		
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
				$this->_js[] = $value->_js;
			}
		}
		else{
			$this->_obj[] = $arg;
			$this->_js[] = $arg->_js;
		}
		$this->refreshInfo();	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
}