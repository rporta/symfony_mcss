<?php 

/**
* 
*/
class span extends createClass
{

	public $_text;
	public $_textColor;
	public $_backgroundColor;
	public $_searchData;
	
	function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			foreach ($array as $key => $value) {
				switch (1) {
					case $key == 'textColor':
						$this->_textColor = !empty($value) ? $this->colorsText($value) : "";
						break;
					case $key == 'backgroundColor':
						$this->_backgroundColor = !empty($value) ? $this->colors($value) : "";
						break;
					case $key == 'text':
						$this->_text = !empty($value) ? $value : "";
						break;
				}
			}
		}
		$outHtml = "<span class='{class}'>{text}</span>";
		$search[] = "{class}";
		$search[] = "{text}";

		$replace[] = "{$this->_backgroundColor} {$this->_textColor}";
		$replace[] = "{$this->_text}";

		$this->_html = str_replace($search, $replace, $outHtml);
	}
}