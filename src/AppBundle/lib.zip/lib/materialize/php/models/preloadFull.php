<?php

class preloadFull extends createClass
{
	public $_html;
	public $_js;
	
	public function __construct($section,$preloader){

		$section['z'] = 9;
		$section_p = new section($section); 
			$conteiner_p['align'] = 1;
			$conteiner_p['center'] = true;
			$conteiner_p = new conteiner($conteiner_p); 
				## preloader
				$preloader['name'] = $section['name'];
				$preloader = new preloader($preloader);

			$conteiner_p->addObj($preloader);
		$section_p->addObj($conteiner_p);

		# set js
		$this->_js = " {$preloader->_js} ";

		$this->_html = $section_p->_html;
	}
}