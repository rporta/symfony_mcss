<?php

class pagination extends createClass
{
	public $_textColor;
	public $_backgroundColor;
	public $_effect;
	public $_show;
	public $_limit;
	public $_href;
	public $_active;
	public $_html;
	public function __construct($array = null)
	{
		$this->refreshInfo($array);
	}
	public function refreshInfo($array = null){
		if(!is_null($array)){
			$this->_searchData = $array;
			## set textColor
			if (empty($this->_searchData['textColor'])){ 
				$this->_textColor = false;
			}
			else {
				$this->_textColor = $this->_searchData['textColor'];
			}
			## set backgroundColor
			if (empty($this->_searchData['backgroundColor'])){ 
				$this->_backgroundColor = false;
			}
			else {
				$this->_backgroundColor = $this->_searchData['backgroundColor'];
			}
			## set effect
			if (empty($this->_searchData['effect'])){ 
				$this->_effect = false;
			}
			else {
				$this->_effect = $this->_searchData['effect'];
			}
			## set limit
			if (empty($this->_searchData['limit'])){ 
				$this->_limit = false;
			}
			else {
				$this->_limit = $this->_searchData['limit'];
			}
			## set href este parametro es un string 'pag,item'
			if (empty($this->_searchData['href'])){ 
				$this->_href = false;
			}
			else {
				$this->_href = $this->_searchData['href'];
			}
			## set active
			if (empty($this->_searchData['active'])){ 
				$this->_active = false;
			}
			else {
				$this->_active = $this->_searchData['active'];
			}
		}
		#set html
		$this->setHtml();
	}
	public function setHtml(){


		// arreglar paginador
		$textColor = '';
		$backgroundColor = '';
		$effect = $this->waves(0);
		$show = count($this->_href); //cantidad de paginas que se muestran 
		$limit = 50; //cantidad de paginas 
		$active = 1; //pagina actual id pag
		$activeItem = '';
		
		if($this->_textColor !== false){ $textColor = $this->colorsText($this->_textColor); }	
		if($this->_backgroundColor !== false){ $backgroundColor = $this->colors($this->_backgroundColor); }
		if($this->_effect !== false){ $effect = $this->waves($this->_effect); }

		if($this->_limit !== false){ $limit = $this->_limit; }
		if($this->_active !== false){ $active = $this->_active; }
			// <
			$start = explode(",",reset($this->_href));
			$start[1] = $start[1]-1;
			if(($active - $show) <= 0) {
				$item[] = "<li class='disabled {$effect}'><a href='#!'><i class='material-icons'>chevron_left</i></a></li>";
			}
			else{
				$item[] = "<li class=' {$effect} '><a class='{$textColor}' href='{$start[0]}{$start[1]}'><i class='material-icons'>chevron_left</i></a></li>";
			}
			// items
			if ($active > $show){
				$num = $active - $show + 1;
			}
			else{
				$num = 1;
			}
			for ($i=0; $i < $show; $i++) { 
				if ($num == $active) { 
					$activeItem = " active {$backgroundColor}"; 
					$textColor = "";
				}
				else{ 
					$activeItem = ""; 
					if($this->_textColor !== false){ 
						$textColor = $this->colorsText($this->_textColor); 
					}	
				}
				$link = explode(",", $this->_href[$i]);

				$item[] = "<li class='{$activeItem} {$effect}'><a class='{$textColor}' href='{$link[0]}{$link[1]}'>{$num}</a></li>";
				$num++;
			}
			// >
			$end = explode(",",end($this->_href));
			$end[1] = $end[1]+1;
			if($this->_textColor !== false){ 
				$textColor = $this->colorsText($this->_textColor); 
			}
			if($active == $limit) {
				$item[] = "<li class='disabled {$effect}'><a href='#!'><i class='material-icons'>chevron_right</i></a></li>";
			}
			else{
				$item[] = "<li class='{$effect}'><a class='{$textColor}' href='{$end[0]}{$end[1]}'><i class='material-icons'>chevron_right</i></a></li>";
			}
		$tmp = 
		"<ul class='pagination'>
			{item}
		</ul>";
		$this->_html = str_replace("{item}", implode("", $item), $tmp);
	}
}