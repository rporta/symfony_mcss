<?php

class br extends createClass
{
	public $_repeat;
	public $_html;
	public $_searchData;
	function __construct($arg)
	{
		$this->refreshInfo($arg);
	}
	public function refreshInfo($arg = null){
		$repeat = $this->_repeat = empty($arg) ? 1 : $arg;
		$outHtml =  str_repeat("<br>", $repeat);
		$this->_html = $outHtml;
	}
}