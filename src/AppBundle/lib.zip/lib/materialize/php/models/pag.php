<?php

class pag extends createClass 
{
	public $_type;
	public $_html;
	public $_backgroundColor;
	public $_css;
	public $_js;
	public $_obj;
	public $_version;

	public function __construct($array = null){
		$this->_obj = array();
		$this->_html = "";
		$this->_css = "";
		$this->_js = "";
		if (!empty($array['html'])){
			$this->_html .= " {$array['html']} ";
		}
		if (!empty($array['css'])){
			$this->_css .= " {$array['css']} ";
		}
		if (!empty($array['js'])){
			$this->_js .= " {$array['js']} ";
		}
		if (is_array($array['obj'])){
			foreach ($array['obj'] as $value) {
				$this->obj[] =  $value;
			}
		}
		if (!empty($array['backgroundColor'])){
			$this->_backgroundColor = !empty($array['backgroundColor']) ? $this->colors($array['backgroundColor']) : "";
		}
		if (!empty($array['version'])){
			$this->_version = $array['version'];
		}else{
			$this->_version = false;
		}
	}
	public function render($arg = null){

		$version = $this->_version ? "beta" : "materialize.min";

		$render = "<!DOCTYPE html>
		<html>
		<head>
			<!--Import Google Icon Font-->
			<link href='cms/lib/materialize/css/icon.css' rel='stylesheet'>
			<!--Import materialize.css-->
			<link type='text/css' rel='stylesheet' href='cms/lib/materialize/css/{$version}.css'  media='screen,projection'/>
			<link type='text/css' rel='stylesheet' href='cms/lib/materialize/css/nouislider.css'/>

			<!--Let browser know website is optimized for mobile-->
			<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
			<style type='text/css'>";
		foreach ($this->_obj as $obj) {
			$render .= " {$obj->_css} ";
		}
		$render .=
			"</style>
		</head>
		<body class='{$this->_backgroundColor}'>
			<!--  MCSS-->";
		foreach ($this->_obj as $obj) {
			$render .= " {$obj->_html} ";
		}			
		$render .= "<!--/ MCSS-->
		<script type='text/javascript' src='cms/lib/materialize/js/jquery-3.2.1.min.js'></script>
		<script type='text/javascript' src='cms/lib/materialize/js/{$version}.js'></script>
		<script type='text/javascript' src='cms/lib/materialize/js/nouislider.js'></script>
			<script type='text/javascript' >".
				"$(document).ready(function(){ ";
		foreach ($this->_obj as $obj) {
			$result = $this->record($obj->_js,$asd);
			$render .= "\n {$result} \n";
		}	

		$render .= "$this->_js\n";
		$render .= " });
			</script>
		</body>
		</html>";

		if($arg == 'export'){
			return $render;
		}
		else { 
			echo $render; 
		}
	}
	public function addObj($arg){
		if (is_array($arg)){
			foreach ($arg as $key => $value) {
				$this->_obj[] = $value;
			}
		}
		else{
			$this->_obj[] = $arg;
		}	
	}
	public function deleteObj($array){
		foreach ($this->_obj as $key => $obj) {
			if($obj->_searchData == $array){
				$uK = $key;
			}
		}
		unset($this->_obj[$uK]);
		$this->refreshInfo();
	}
	public function getObj($array){
		$this->refreshInfo();
		foreach ($this->_obj as $obj) {
			if($obj->_searchData == $array){
				return $obj;
			}
		}
	}
	public function record($array, &$list){
		if(is_array($array)){
		    foreach ($array as $key => $value) {
		        if (is_array($value)) {
		            $this->record($value, $list);
		        }
		        else{
		        	if(!empty($value) && is_string($value)){
		        		$list[] = $value;
		        	}
		        }
		    }
		    if(is_array($list)) {
		    	return implode("", $list);
		    }
		    else{
		    	return $list;
		    }
		}
		else{
			if(!empty($array)){
				return $array;
			}
		}
	}
}
