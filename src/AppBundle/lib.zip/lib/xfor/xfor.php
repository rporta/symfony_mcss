<?php 
function xfor($array, $key, $mode = NULL) {
	if(empty($mode)){
		foreach ($array as $value) {
			$out[] = $value[$key];
		}
		return $out;
	}
	else{
		foreach ($array as $value) {
			if (key($value) == $key && $key !== 'preloader:backgroundColor_array'){
				return $value[key($value)];
			}
			elseif(key($value) == 'preloader:backgroundColor_array'){
				$salida[] = $value[key($value)];
			}
		}
		return $salida;
	}
}
function xkey($array, $value) {
	foreach ($array as $key => $value2) {
		if($value == $value2){
			return $key;
		}
	}
}